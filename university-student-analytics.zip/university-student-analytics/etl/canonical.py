"""
Canonical table builder.

Orchestrates: spine generation → alignment → feature engineering → output.
Produces the final wide-format student-term table ready for analysis.
"""
import pandas as pd
from config.settings import TERM_START_DATES, OUTPUT_DIR
from etl.spine import build_spine
from etl.alignment import align_to_spine, fill_defaults
from etl.features import engineer_features


def build_canonical_table(raw_df: pd.DataFrame, save: bool = True) -> pd.DataFrame:
    """
    Build the canonical student-term table from raw wide-format data.

    Parameters
    ----------
    raw_df : DataFrame in wide format (one row per student-term with all signals).
    save : If True, write to CSV and return.

    Returns
    -------
    The fully-featured canonical DataFrame.
    """
    print("[canonical] Building spine...")
    spine = build_spine(raw_df, extra_terms=2)
    print(f"  Spine: {len(spine):,} rows ({spine['student_id'].nunique():,} students)")

    print("[canonical] Aligning to spine...")
    aligned = align_to_spine(spine, raw_df)

    print("[canonical] Filling defaults...")
    aligned = fill_defaults(aligned)

    # Ensure term_start_date is present
    if "term_start_date" not in aligned.columns:
        aligned["term_start_date"] = aligned["term_code"].map(TERM_START_DATES)

    print("[canonical] Engineering features...")
    canonical = engineer_features(aligned)

    n_rows, n_cols = canonical.shape
    print(f"[canonical] Final table: {n_rows:,} rows × {n_cols} columns")

    if save:
        out_path = OUTPUT_DIR / "canonical_student_signals.csv"
        canonical.to_csv(out_path, index=False)
        print(f"[canonical] Saved to {out_path}")

    return canonical
