"""
Temporal alignment utilities.

Handles:
- Forward-filling numeric columns for gap terms
- Propagating static (enrollment-time) fields across all terms
- Aligning weekly signals to term-level aggregates
"""
import pandas as pd
import numpy as np

# Columns that are static per student (set once, carry forward)
STATIC_COLS = [
    "age", "gender", "ethnicity", "first_generation", "prior_education",
    "military_status", "dependents", "years_since_last_education",
    "program_code", "program_level", "transfer_credits", "modality",
    "orientation_completed", "accommodation_active", "archetype_true",
]

# Columns to forward-fill (last observed value carries into gap terms)
FFILL_COLS = [
    "cumulative_gpa", "total_lifetime_charges", "employment_status",
    "enrollment_status", "program_change_count",
]


def align_to_spine(spine: pd.DataFrame, raw: pd.DataFrame) -> pd.DataFrame:
    """
    Merge raw data onto the spine and handle missing values.

    1. Left-join raw onto spine (some spine rows will have NaN).
    2. Forward-fill specified columns within each student.
    3. Propagate static columns.
    4. Fill remaining NaN with sensible defaults.
    """
    merged = spine.merge(raw, on=["student_id", "term_code"], how="left", suffixes=("", "_dup"))

    # Drop duplicate columns from merge
    dup_cols = [c for c in merged.columns if c.endswith("_dup")]
    merged.drop(columns=dup_cols, inplace=True)

    # Use term_sequence from spine if available
    if "term_sequence_dup" in merged.columns:
        merged.drop(columns=["term_sequence_dup"], inplace=True, errors="ignore")

    merged.sort_values(["student_id", "term_code"], inplace=True)

    # Forward-fill within student
    for col in FFILL_COLS:
        if col in merged.columns:
            merged[col] = merged.groupby("student_id")[col].ffill()

    # Propagate static cols (take first non-null per student)
    for col in STATIC_COLS:
        if col in merged.columns:
            first_vals = merged.groupby("student_id")[col].first()
            merged[col] = merged["student_id"].map(first_vals)

    return merged


def fill_defaults(df: pd.DataFrame) -> pd.DataFrame:
    """Fill remaining NaN with type-appropriate defaults."""
    # Numeric columns: fill with 0
    num_cols = df.select_dtypes(include=[np.number]).columns
    df[num_cols] = df[num_cols].fillna(0)

    # String/categorical columns: fill with 'unknown'
    str_cols = df.select_dtypes(include=["object"]).columns
    df[str_cols] = df[str_cols].fillna("unknown")

    return df
