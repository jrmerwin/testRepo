"""
Spine generator: builds the complete student_id × term_code grid.

The spine ensures every student has a row for every term from their first
enrollment through graduation or last activity + 2 terms. Missing terms
are forward-filled from the last observed values during alignment.
"""
import pandas as pd
from config.settings import TERM_CODES


def build_spine(df: pd.DataFrame, extra_terms: int = 2) -> pd.DataFrame:
    """
    Build a student × term spine from observed data.

    Parameters
    ----------
    df : DataFrame with at least student_id and term_code columns.
    extra_terms : Number of terms to extend past last observed activity.

    Returns
    -------
    DataFrame with student_id, term_code, term_sequence, and an
    'observed' boolean column indicating whether real data exists.
    """
    term_order = {tc: i for i, tc in enumerate(TERM_CODES)}

    # Find first and last observed term per student
    df_terms = df[["student_id", "term_code"]].drop_duplicates()
    df_terms["term_idx"] = df_terms["term_code"].map(term_order)

    bounds = df_terms.groupby("student_id")["term_idx"].agg(["min", "max"]).reset_index()
    bounds.columns = ["student_id", "first_idx", "last_idx"]
    bounds["last_idx"] = (bounds["last_idx"] + extra_terms).clip(upper=len(TERM_CODES) - 1)

    # Expand to full grid
    rows = []
    for _, row in bounds.iterrows():
        for idx in range(row["first_idx"], row["last_idx"] + 1):
            rows.append({
                "student_id": row["student_id"],
                "term_code": TERM_CODES[idx],
                "term_sequence": idx - row["first_idx"] + 1,
            })
    spine = pd.DataFrame(rows)

    # Mark which rows have observed data
    observed_keys = set(zip(df["student_id"], df["term_code"]))
    spine["observed"] = spine.apply(
        lambda r: (r["student_id"], r["term_code"]) in observed_keys, axis=1
    )
    return spine
