"""
Feature engineering for the canonical table.

Creates:
- Composite z-score indices (academic momentum, engagement, etc.)
- Lag features (t-1, t-2 values)
- Delta features (term-over-term changes)
- Cross-group ratio features
- Data completeness score
"""
import pandas as pd
import numpy as np
from scipy.stats import zscore
from config.settings import (
    COMPOSITE_INDICES, LAG_FEATURES, DELTA_FEATURES, RATIO_FEATURES,
)


def engineer_features(df: pd.DataFrame) -> pd.DataFrame:
    """Apply all feature engineering steps to the canonical DataFrame."""
    df = df.copy()
    df.sort_values(["student_id", "term_code"], inplace=True)

    df = _add_composites(df)
    df = _add_lags(df)
    df = _add_deltas(df)
    df = _add_ratios(df)
    df = _add_completeness(df)
    return df


def _add_composites(df: pd.DataFrame) -> pd.DataFrame:
    """Compute composite z-score indices."""
    for idx_name, spec in COMPOSITE_INDICES.items():
        components = [c for c in spec["components"] if c in df.columns]
        if not components:
            continue
        signs = spec.get("signs", [1] * len(components))
        z_cols = []
        for col, sign in zip(components, signs):
            col_data = pd.to_numeric(df[col], errors="coerce")
            std = col_data.std()
            if std > 0:
                z = (col_data - col_data.mean()) / std * sign
            else:
                z = pd.Series(0.0, index=df.index)
            z_cols.append(z)
        df[idx_name] = pd.concat(z_cols, axis=1).mean(axis=1).round(4)
    return df


def _add_lags(df: pd.DataFrame) -> pd.DataFrame:
    """Add lagged versions of key metrics."""
    for col, lags in LAG_FEATURES.items():
        if col not in df.columns:
            continue
        for lag in lags:
            lag_name = f"{col}_lag{lag}"
            df[lag_name] = df.groupby("student_id")[col].shift(lag)
    return df


def _add_deltas(df: pd.DataFrame) -> pd.DataFrame:
    """Add term-over-term change features."""
    for delta_name, source_col, periods in DELTA_FEATURES:
        if source_col not in df.columns:
            continue
        if periods == 1:
            df[delta_name] = df.groupby("student_id")[source_col].diff(1)
        else:
            # Slope over N terms using simple linear regression
            def _slope(series):
                vals = series.values
                result = np.full(len(vals), np.nan)
                for i in range(periods - 1, len(vals)):
                    window = vals[i - periods + 1: i + 1]
                    valid = ~np.isnan(window)
                    if valid.sum() >= 2:
                        x = np.arange(valid.sum())
                        y = window[valid]
                        if len(x) > 1:
                            slope = np.polyfit(x, y, 1)[0]
                            result[i] = slope
                return pd.Series(result, index=series.index)
            df[delta_name] = df.groupby("student_id")[source_col].transform(_slope)
    return df


def _add_ratios(df: pd.DataFrame) -> pd.DataFrame:
    """Add cross-group ratio features."""
    for ratio_name, (num_col, den_col) in RATIO_FEATURES.items():
        if num_col in df.columns and den_col in df.columns:
            num = pd.to_numeric(df[num_col], errors="coerce")
            den = pd.to_numeric(df[den_col], errors="coerce")
            if ratio_name == "engagement_academic_gap":
                # Difference, not ratio
                df[ratio_name] = (num - den).round(4)
            else:
                df[ratio_name] = (num / den.replace(0, np.nan)).round(4)
    return df


def _add_completeness(df: pd.DataFrame) -> pd.DataFrame:
    """Score each row's data completeness (fraction of non-null numeric columns)."""
    num_cols = df.select_dtypes(include=[np.number]).columns
    df["data_completeness"] = df[num_cols].notna().mean(axis=1).round(4)
    return df
