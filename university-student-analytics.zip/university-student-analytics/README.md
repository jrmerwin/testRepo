# University Student Systems Analytics

A systems-level student analytics platform for online universities, implementing a complete
analytical pipeline from raw signals through causal inference and intervention modeling.

## Architecture

```
Raw signals (long format)
  → ETL: alignment, spine generation
  → Canonical student-term table (wide format)
  → Feature engineering (composites, lags, deltas, ratios)
  → Clustering → student archetypes
  → PCA → independent dimensions
  → Correlation matrix → cross-group relationships
  → Lag analysis → leading indicators
  → Granger causality → directed causal edges
  → Systems graph → formal causal map
  → VAR models → impulse response (intervention modeling)
  → Markov transitions → archetype stability
  → Scenario engine → intervention what-ifs
```

## Quick Start

```bash
# 1. Create virtual environment
python -m venv .venv
source .venv/bin/activate  # Linux/Mac
# .venv\Scripts\activate   # Windows

# 2. Install dependencies
pip install -r requirements.txt

# 3. Run the full pipeline
python scripts/01_generate_data.py
python scripts/02_build_canonical.py
python scripts/03_descriptive_analysis.py
python scripts/04_systems_analysis.py
python scripts/05_run_scenarios.py
```

Each script is self-contained and saves results to `outputs/` and DuckDB.

## Project Structure

```
config/settings.py           — Signal groups, archetypes, all parameters
storage/database.py          — DuckDB setup, table creation, queries
collectors/synthetic_generator.py — Realistic synthetic data with baked-in correlations
etl/spine.py                 — Student × term spine generation
etl/alignment.py             — Temporal alignment of signals
etl/features.py              — Feature engineering (composites, lags, deltas)
etl/canonical.py             — Build the canonical wide table
analysis/descriptive/pca.py        — PCA analysis
analysis/descriptive/clustering.py — K-Means / archetype discovery
analysis/descriptive/profiling.py  — Cluster profiling
analysis/systems/correlation.py    — Cross-group correlation matrix
analysis/systems/lag_analysis.py   — Lagged leading-indicator analysis
analysis/systems/granger.py        — Granger causality tests
analysis/systems/systems_graph.py  — Causal graph construction
analysis/systems/var_models.py     — VAR impulse response models
analysis/systems/markov.py         — Markov transition dynamics
analysis/systems/scenario_engine.py — Intervention what-if engine
scripts/01-05                      — Pipeline runner scripts
```

## Signal Groups (10 Orthogonal Dimensions)

1. **Academic Performance** — GPA, completion rates, standing
2. **Engagement & Activity** — LMS logins, discussion, video watch
3. **Financial** — Tuition balance, aid, payment status
4. **Support & Intervention** — Advising, tutoring, early alerts
5. **Demographics & Background** — Age, first-gen, employment
6. **Program & Enrollment** — Program, modality, intensity
7. **Course-Level Signals** — Class size, difficulty, instructor ratings
8. **Communication & Sentiment** — Email engagement, surveys, NPS
9. **Connectivity & Technology** — Connection speed, device, errors
10. **Outcomes** — Retention, graduation, stopout

## Swapping in Real Data

The synthetic generator (`collectors/synthetic_generator.py`) can be replaced with real
data extractors that produce the same schema. The canonical table schema in `config/settings.py`
is the contract — any data source that produces matching columns will work.

## Technology Stack

- Python 3.10+
- DuckDB (analytical storage)
- pandas, numpy, scikit-learn, statsmodels, scipy
- networkx (systems graph)
- matplotlib, seaborn (visualization)
