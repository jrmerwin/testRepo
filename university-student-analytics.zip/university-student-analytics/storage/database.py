"""
DuckDB storage layer for the student analytics pipeline.

Handles database creation, table management, and common queries.
Pattern: long-format signals table → wide-format canonical table.
"""
import duckdb
import pandas as pd
from pathlib import Path
from config.settings import DB_PATH, OUTPUT_DIR


class StudentDB:
    """Thin wrapper around DuckDB for the student analytics pipeline."""

    def __init__(self, db_path: Path = DB_PATH):
        self.db_path = db_path
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.conn = duckdb.connect(str(self.db_path))
        self._init_tables()

    def _init_tables(self):
        """Create core tables if they don't exist."""
        self.conn.execute("""
            CREATE TABLE IF NOT EXISTS raw_signals (
                student_id   VARCHAR,
                term_code    VARCHAR,
                signal_group VARCHAR,
                metric_name  VARCHAR,
                metric_value DOUBLE,
                metric_str   VARCHAR,       -- for categorical values
                created_at   TIMESTAMP DEFAULT current_timestamp
            )
        """)
        self.conn.execute("""
            CREATE TABLE IF NOT EXISTS canonical (
                student_id      VARCHAR,
                term_code       VARCHAR,
                term_start_date DATE,
                term_sequence   INTEGER
                -- remaining columns added dynamically via ALTER or CTAS
            )
        """)
        self.conn.execute("""
            CREATE TABLE IF NOT EXISTS cluster_assignments (
                student_id VARCHAR,
                term_code  VARCHAR,
                cluster_id INTEGER,
                archetype_label VARCHAR
            )
        """)
        self.conn.execute("""
            CREATE TABLE IF NOT EXISTS analysis_results (
                analysis_name VARCHAR,
                run_date      TIMESTAMP DEFAULT current_timestamp,
                params_json   VARCHAR,
                results_json  VARCHAR
            )
        """)

    # ── Data loading ─────────────────────────────────────────────────────
    def load_raw_signals(self, df: pd.DataFrame):
        """Bulk-insert a DataFrame into raw_signals (append)."""
        self.conn.execute("INSERT INTO raw_signals SELECT * FROM df")

    def replace_canonical(self, df: pd.DataFrame):
        """Replace the canonical table entirely from a DataFrame."""
        self.conn.execute("DROP TABLE IF EXISTS canonical")
        self.conn.execute("CREATE TABLE canonical AS SELECT * FROM df")

    def save_clusters(self, df: pd.DataFrame):
        """Save cluster assignments."""
        self.conn.execute("DELETE FROM cluster_assignments")
        self.conn.execute("INSERT INTO cluster_assignments SELECT * FROM df")

    def save_analysis(self, name: str, params: str, results: str):
        """Log an analysis run."""
        self.conn.execute(
            "INSERT INTO analysis_results (analysis_name, params_json, results_json) VALUES (?, ?, ?)",
            [name, params, results],
        )

    # ── Queries ──────────────────────────────────────────────────────────
    def get_canonical(self) -> pd.DataFrame:
        """Return the full canonical table as a DataFrame."""
        return self.conn.execute("SELECT * FROM canonical").fetchdf()

    def get_raw_signals(self, group: str = None) -> pd.DataFrame:
        """Return raw signals, optionally filtered by group."""
        if group:
            return self.conn.execute(
                "SELECT * FROM raw_signals WHERE signal_group = ?", [group]
            ).fetchdf()
        return self.conn.execute("SELECT * FROM raw_signals").fetchdf()

    def query(self, sql: str) -> pd.DataFrame:
        """Run arbitrary SQL and return a DataFrame."""
        return self.conn.execute(sql).fetchdf()

    def execute(self, sql: str, params=None):
        """Run arbitrary SQL (no return)."""
        if params:
            self.conn.execute(sql, params)
        else:
            self.conn.execute(sql)

    def table_info(self, table: str = "canonical") -> pd.DataFrame:
        """Return column names and types for a table."""
        return self.conn.execute(f"DESCRIBE {table}").fetchdf()

    def row_count(self, table: str = "canonical") -> int:
        return self.conn.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]

    def close(self):
        self.conn.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()
