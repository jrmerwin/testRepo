"""
Synthetic data generator for the student analytics pipeline.

Generates realistic student-term panel data with baked-in correlations,
temporal dynamics, and intervention effects. Students are drawn from
latent archetypes, then noise is added.

Design: each student is assigned an archetype at creation. The archetype
determines base parameters. Term-by-term evolution adds trends, noise,
and intervention effects to create realistic trajectories.
"""
import numpy as np
import pandas as pd
from config.settings import (
    ARCHETYPES, TERM_CODES, TERM_START_DATES,
    NUM_STUDENTS, RANDOM_SEED,
)


class SyntheticGenerator:
    """Generate a canonical-shaped DataFrame of synthetic student-term data."""

    def __init__(self, n_students: int = NUM_STUDENTS, seed: int = RANDOM_SEED):
        self.n_students = n_students
        self.rng = np.random.default_rng(seed)
        self.students = []   # list of student metadata dicts
        self.records = []    # list of student-term row dicts

    # ── Public API ───────────────────────────────────────────────────────
    def generate(self) -> pd.DataFrame:
        """Run full generation and return a wide-format DataFrame."""
        self._create_students()
        self._generate_trajectories()
        df = pd.DataFrame(self.records)
        df["term_start_date"] = df["term_code"].map(TERM_START_DATES)
        return df

    # ── Student creation ─────────────────────────────────────────────────
    def _create_students(self):
        """Assign each student an archetype and static attributes."""
        archetype_names = list(ARCHETYPES.keys())
        proportions = [ARCHETYPES[a]["proportion"] for a in archetype_names]
        proportions = np.array(proportions) / sum(proportions)

        assignments = self.rng.choice(
            archetype_names, size=self.n_students, p=proportions
        )
        for i, arch_name in enumerate(assignments):
            params = ARCHETYPES[arch_name]["params"]
            sid = f"STU{i+1:06d}"

            # Static demographics
            age = int(np.clip(self.rng.normal(params["age_mean"], params["age_std"]), 17, 70))
            gender = self.rng.choice(["M", "F", "Other"], p=[0.42, 0.55, 0.03])
            ethnicity = self.rng.choice(
                ["White", "Black", "Hispanic", "Asian", "Other"],
                p=[0.50, 0.18, 0.18, 0.08, 0.06],
            )
            first_gen = int(self.rng.random() < params.get("first_gen_prob", 0.30))
            emp_probs = params["employment"]
            employment = self.rng.choice(
                list(emp_probs.keys()), p=list(emp_probs.values())
            )
            military = "none"
            if params.get("military_prob", 0) > 0:
                if self.rng.random() < params["military_prob"]:
                    military = self.rng.choice(["active", "veteran", "dependent"], p=[0.1, 0.7, 0.2])
            prior_ed = self.rng.choice(
                ["hs", "some_college", "associate", "bachelor_plus"],
                p=[0.35, 0.30, 0.20, 0.15],
            )
            dependents = int(self.rng.poisson(1.2 if age > 30 else 0.3))
            years_gap = max(0, int(self.rng.exponential(3 if age > 25 else 0.5)))

            # Enrollment
            start_idx = self.rng.integers(0, min(6, len(TERM_CODES)))
            n_terms = int(np.clip(self.rng.normal(8, 3), 2, len(TERM_CODES) - start_idx))
            program = self.rng.choice(["BUS", "CS", "NURS", "EDU", "PSYCH", "CJ", "IT", "COMM"])
            program_level = self.rng.choice(
                ["associate", "bachelor", "master", "certificate"],
                p=[0.15, 0.55, 0.20, 0.10],
            )
            transfer_credits = int(self.rng.exponential(15)) if prior_ed != "hs" else 0
            modality = self.rng.choice(["online", "hybrid", "in_person"], p=[0.70, 0.20, 0.10])

            self.students.append({
                "student_id": sid,
                "archetype": arch_name,
                "age": age, "gender": gender, "ethnicity": ethnicity,
                "first_generation": first_gen, "prior_education": prior_ed,
                "military_status": military, "employment_status": employment,
                "dependents": dependents, "years_since_last_education": years_gap,
                "program_code": program, "program_level": program_level,
                "enrollment_status": params.get("enrollment_status", "full_time"),
                "transfer_credits": transfer_credits, "modality": modality,
                "start_term_idx": start_idx, "n_terms": n_terms,
                "params": params,
            })

    # ── Trajectory generation ────────────────────────────────────────────
    def _generate_trajectories(self):
        """Generate term-by-term records for every student."""
        for stu in self.students:
            self._generate_student_trajectory(stu)

    def _generate_student_trajectory(self, stu: dict):
        params = stu["params"]
        arch = stu["archetype"]

        # Base state
        base_gpa = np.clip(self.rng.normal(params["gpa_mean"], params["gpa_std"]), 0, 4.0)
        base_engagement = params["engagement_factor"]
        base_aid = params.get("financial_aid_pct_mean", 0.4)
        credits_mean = params.get("credits_mean", 12)
        credits_std = params.get("credits_std", 3)
        retention_p = params["retention_prob"]
        gpa_trend = params.get("gpa_trend", 0.0)
        eng_decay = params.get("engagement_decay", 0.0)
        fin_stress = params.get("financial_stress_high", False)
        employer_assist = self.rng.random() < params.get("employer_assist_prob", 0.10)

        cum_credits = stu["transfer_credits"]
        cum_gpa_sum = 0
        cum_gpa_n = 0
        active = True
        graduated = False
        stopped_out = False
        terms_inactive = 0
        program_changes = 0
        orientation = int(self.rng.random() < 0.80)
        accommodation = int(self.rng.random() < 0.08)
        lifetime_charges = 0.0

        for t in range(stu["n_terms"]):
            term_idx = stu["start_term_idx"] + t
            if term_idx >= len(TERM_CODES):
                break
            tc = TERM_CODES[term_idx]
            term_seq = t + 1

            # ── Check if student is still active ──
            if not active:
                terms_inactive += 1
                if terms_inactive <= 2:
                    # Record a gap term for Markov analysis
                    self.records.append(self._gap_row(stu, tc, term_seq, stopped_out, graduated))
                continue

            # ── Academic ──
            noise = self.rng.normal(0, 0.25)
            term_gpa = np.clip(base_gpa + gpa_trend * t + noise, 0, 4.0)
            credits_att = int(np.clip(self.rng.normal(credits_mean, credits_std), 1, 18))

            # Credit completion correlated with GPA
            comp_rate = np.clip(0.5 + 0.12 * term_gpa + self.rng.normal(0, 0.08), 0, 1)
            credits_earned = int(round(credits_att * comp_rate))
            cum_credits += credits_earned
            cum_gpa_sum += term_gpa * credits_att
            cum_gpa_n += credits_att
            cum_gpa = cum_gpa_sum / max(cum_gpa_n, 1)

            assign_score = np.clip(term_gpa * 22 + self.rng.normal(5, 5), 0, 100)
            assign_sub_rate = np.clip(0.4 + 0.15 * term_gpa + self.rng.normal(0, 0.08), 0, 1)
            failed = max(0, int(self.rng.poisson(max(0, 2.0 - term_gpa))))
            standing = "good" if term_gpa >= 2.0 else ("warning" if term_gpa >= 1.5 else "probation")
            if cum_gpa < 1.0 and t > 1:
                standing = "suspension"

            # ── Engagement (correlated with GPA and archetype) ──
            eng_factor = max(0.05, base_engagement - eng_decay * t + self.rng.normal(0, 0.08))
            logins = max(0, self.rng.normal(eng_factor * 25, 5))
            session_dur = max(0, self.rng.normal(eng_factor * 50, 15))
            disc_posts = max(0, int(self.rng.poisson(eng_factor * 8)))
            disc_replies = max(0, int(self.rng.poisson(eng_factor * 5)))
            video_pct = np.clip(eng_factor + self.rng.normal(0, 0.1), 0, 1)
            resources = max(0, int(self.rng.poisson(eng_factor * 10)))
            mobile_ratio = np.clip(self.rng.beta(2, 3), 0, 1)
            last_login = max(0, int(self.rng.exponential(5 / max(eng_factor, 0.1))))
            login_trend = -eng_decay * 5 + self.rng.normal(0, 0.5)

            # ── Financial ──
            tuition_per_credit = self.rng.normal(400, 50)
            gross_tuition = credits_att * tuition_per_credit
            lifetime_charges += gross_tuition
            aid_pct = np.clip(base_aid + self.rng.normal(0, 0.1), 0, 1)
            scholarship = max(0, aid_pct * gross_tuition * self.rng.uniform(0.3, 0.7))
            balance = max(0, gross_tuition * (1 - aid_pct) - scholarship)
            if fin_stress:
                balance *= self.rng.uniform(1.2, 2.0)
            payment_ok = int(self.rng.random() < (0.9 if not fin_stress else 0.50))
            plan_active = int(not payment_ok and self.rng.random() < 0.6)
            fees = max(0, self.rng.normal(200, 100)) if not payment_ok else 0
            refund = int(failed > 0 and self.rng.random() < 0.3)

            # ── Support ──
            at_risk = term_gpa < 2.0 or eng_factor < 0.35
            adv_init = max(0, int(self.rng.poisson(2 if at_risk else 0.5)))
            stu_init = max(0, int(self.rng.poisson(1.5 if term_gpa > 3.0 else 0.5)))
            adv_total = adv_init + stu_init
            tutoring = max(0, int(self.rng.poisson(3 if term_gpa < 2.5 else 0.5)))
            early_alerts = max(0, int(self.rng.poisson(2 if at_risk else 0.2)))
            support_tix = max(0, int(self.rng.poisson(1.0)))
            mentoring = int(self.rng.random() < (0.25 if at_risk else 0.08))

            # ── Course-level ──
            class_size = max(5, int(self.rng.normal(35, 15)))
            course_diff = np.clip(self.rng.normal(2.8, 0.4), 1.5, 3.8)
            live_pct = np.clip(self.rng.beta(2, 5), 0, 1)
            instr_rating = np.clip(self.rng.normal(3.8, 0.6), 1, 5)
            format_div = self.rng.integers(1, 5)
            prereq_met = np.clip(self.rng.beta(5, 1), 0, 1)
            hist_comp = np.clip(self.rng.beta(5, 2), 0.3, 1)

            # ── Communication ──
            email_open = np.clip(eng_factor * 0.7 + self.rng.normal(0, 0.1), 0, 1)
            email_click = np.clip(email_open * 0.3 + self.rng.normal(0, 0.05), 0, 0.5)
            survey_resp = np.clip(eng_factor * 0.5 + self.rng.normal(0, 0.1), 0, 1)
            satisfaction = np.clip(term_gpa * 0.8 + self.rng.normal(0.5, 0.5), 1, 5)
            sentiment = np.clip(self.rng.normal(0.1 if term_gpa > 2.5 else -0.3, 0.3), -1, 1)
            complaints = max(0, int(self.rng.poisson(0.1 if term_gpa > 2.0 else 0.8)))
            nps = np.clip(self.rng.normal(satisfaction * 20 - 30, 20), -100, 100)

            # ── Technology ──
            speed = max(1, self.rng.lognormal(3.5, 0.8))
            tech_tix = max(0, int(self.rng.poisson(0.8)))
            device = self.rng.choice(["desktop", "laptop", "tablet", "phone"], p=[0.2, 0.5, 0.1, 0.2])
            browsers = self.rng.integers(1, 5)
            proctor_issues = max(0, int(self.rng.poisson(0.3)))
            lms_errors = np.clip(self.rng.exponential(0.03), 0, 0.3)

            # ── Outcomes ──
            # Intervention effect: advisor outreach boosts retention
            intervention_boost = 0.0
            if adv_init > 0 and at_risk:
                intervention_boost = 0.15 * adv_init
            elif adv_init > 0:
                intervention_boost = 0.05 * adv_init
            if tutoring > 2 and term_gpa < 2.5:
                intervention_boost += 0.08

            ret_prob = np.clip(
                retention_p
                + 0.08 * (term_gpa - 2.5)
                + 0.05 * (eng_factor - 0.5)
                - 0.10 * (1 if fin_stress and not payment_ok else 0)
                + intervention_boost
                + self.rng.normal(0, 0.05),
                0.05, 0.99,
            )
            retained = int(self.rng.random() < ret_prob)
            if cum_credits >= 120 and cum_gpa >= 2.0 and t >= 6:
                graduated = self.rng.random() < 0.7
            ttd_pct = min(2.0, cum_credits / 120)
            if graduated:
                status = "graduated"
            elif standing == "suspension":
                status = "dismissed"
                retained = 0
            elif not retained:
                status = "withdrawn"
            else:
                status = "active"

            # ── Enrollment meta ──
            if self.rng.random() < 0.03 and t > 2:
                program_changes += 1

            row = {
                "student_id": stu["student_id"],
                "term_code": tc,
                "term_start_date": TERM_START_DATES[tc],
                "term_sequence": term_seq,
                "archetype_true": arch,
                # Academic
                "term_gpa": round(term_gpa, 3),
                "cumulative_gpa": round(cum_gpa, 3),
                "credits_attempted": credits_att,
                "credits_earned": credits_earned,
                "credit_completion_rate": round(comp_rate, 3),
                "assignment_avg_score": round(assign_score, 2),
                "assignment_submission_rate": round(assign_sub_rate, 3),
                "failed_courses": failed,
                "academic_standing": standing,
                # Engagement
                "lms_logins_per_week": round(logins, 2),
                "lms_session_duration_min": round(session_dur, 2),
                "discussion_posts": disc_posts,
                "discussion_replies": disc_replies,
                "video_watch_pct": round(video_pct, 3),
                "resource_downloads": resources,
                "mobile_vs_desktop_ratio": round(mobile_ratio, 3),
                "last_login_days_ago": last_login,
                "weekly_login_trend": round(login_trend, 3),
                # Financial
                "tuition_balance": round(balance, 2),
                "financial_aid_pct": round(aid_pct, 3),
                "payment_on_time": payment_ok,
                "payment_plan_active": plan_active,
                "scholarship_amount": round(scholarship, 2),
                "employer_tuition_assist": int(employer_assist),
                "outstanding_fees": round(fees, 2),
                "refund_issued": refund,
                "total_lifetime_charges": round(lifetime_charges, 2),
                # Support
                "advisor_contacts": adv_total,
                "advisor_initiated": adv_init,
                "student_initiated": stu_init,
                "tutoring_sessions": tutoring,
                "early_alert_count": early_alerts,
                "support_ticket_count": support_tix,
                "accommodation_active": accommodation,
                "mentoring_program": mentoring,
                "orientation_completed": orientation,
                # Demographics (static per student)
                "age": stu["age"],
                "gender": stu["gender"],
                "ethnicity": stu["ethnicity"],
                "first_generation": stu["first_generation"],
                "prior_education": stu["prior_education"],
                "military_status": stu["military_status"],
                "employment_status": stu["employment_status"],
                "dependents": stu["dependents"],
                "years_since_last_education": stu["years_since_last_education"],
                # Program
                "program_code": stu["program_code"],
                "program_level": stu["program_level"],
                "enrollment_status": stu["enrollment_status"],
                "enrollment_intensity": round(credits_att / 18, 3),
                "terms_enrolled": term_seq,
                "terms_since_start": term_seq + int(self.rng.exponential(0.3)),
                "transfer_credits": stu["transfer_credits"],
                "program_change_count": program_changes,
                "modality": stu["modality"],
                # Course-level
                "avg_class_size": class_size,
                "avg_course_difficulty": round(course_diff, 3),
                "pct_courses_with_live_sessions": round(live_pct, 3),
                "instructor_avg_rating": round(instr_rating, 3),
                "course_format_diversity": format_div,
                "prerequisite_met_pct": round(prereq_met, 3),
                "avg_course_completion_rate": round(hist_comp, 3),
                # Communication
                "email_open_rate": round(email_open, 3),
                "email_click_rate": round(email_click, 3),
                "survey_response_rate": round(survey_resp, 3),
                "last_survey_satisfaction": round(satisfaction, 2),
                "support_ticket_sentiment": round(sentiment, 3),
                "complaint_count": complaints,
                "net_promoter_score": round(nps, 1),
                # Technology
                "avg_connection_speed": round(speed, 2),
                "tech_support_tickets": tech_tix,
                "device_type": device,
                "browser_diversity": browsers,
                "proctoring_issues": proctor_issues,
                "lms_error_rate": round(lms_errors, 4),
                # Outcomes
                "retained_next_term": retained,
                "graduated": int(graduated),
                "stopped_out": 0,
                "time_to_degree_pct": round(ttd_pct, 3),
                "active_status": status,
            }
            self.records.append(row)

            # Decide if student continues
            if graduated or not retained:
                active = False
                stopped_out = not graduated

    def _gap_row(self, stu, term_code, term_seq, stopped_out, graduated):
        """Minimal row for a gap/inactive term."""
        return {
            "student_id": stu["student_id"],
            "term_code": term_code,
            "term_start_date": TERM_START_DATES[term_code],
            "term_sequence": term_seq,
            "archetype_true": stu["archetype"],
            "active_status": "graduated" if graduated else ("stopped_out" if stopped_out else "LOA"),
            "retained_next_term": 0,
            "graduated": int(graduated),
            "stopped_out": int(stopped_out),
            **{k: np.nan for k in [
                "term_gpa", "cumulative_gpa", "credits_attempted", "credits_earned",
                "credit_completion_rate", "assignment_avg_score", "assignment_submission_rate",
                "failed_courses", "lms_logins_per_week", "lms_session_duration_min",
                "discussion_posts", "discussion_replies", "video_watch_pct",
                "resource_downloads", "tuition_balance", "financial_aid_pct",
                "scholarship_amount", "outstanding_fees", "total_lifetime_charges",
                "advisor_contacts", "advisor_initiated", "student_initiated",
                "tutoring_sessions", "early_alert_count", "support_ticket_count",
                "email_open_rate", "email_click_rate", "survey_response_rate",
                "last_survey_satisfaction", "support_ticket_sentiment", "net_promoter_score",
                "avg_connection_speed", "lms_error_rate", "time_to_degree_pct",
            ]},
            # Static fields carry forward
            "age": stu["age"], "gender": stu["gender"], "ethnicity": stu["ethnicity"],
            "first_generation": stu["first_generation"],
            "prior_education": stu["prior_education"],
            "military_status": stu["military_status"],
            "employment_status": stu["employment_status"],
            "dependents": stu["dependents"],
            "years_since_last_education": stu["years_since_last_education"],
            "program_code": stu["program_code"],
            "program_level": stu["program_level"],
            "modality": stu["modality"],
            "transfer_credits": stu["transfer_credits"],
        }
