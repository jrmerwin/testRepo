"""
Cluster profiling: characterize each discovered archetype.

For each cluster, compute mean/median of key metrics, identify
distinguishing features, and generate profile summaries.
"""
import pandas as pd
import numpy as np
from config.settings import OUTPUT_DIR, SIGNAL_GROUPS, get_numeric_columns


def profile_clusters(df: pd.DataFrame) -> pd.DataFrame:
    """
    Compute per-cluster profiles across all numeric signal columns.

    Returns a DataFrame: rows = metrics, columns = cluster_id.
    """
    if "cluster_id" not in df.columns:
        raise ValueError("DataFrame must have a 'cluster_id' column. Run clustering first.")

    num_cols = [c for c in get_numeric_columns() if c in df.columns]
    # Add engineered features
    extra = [c for c in df.columns if c.endswith("_index")]
    all_cols = list(set(num_cols + extra))
    all_cols = sorted([c for c in all_cols if c in df.columns])

    profiles = df.groupby("cluster_id")[all_cols].mean().T
    profiles.columns = [f"cluster_{c}" for c in profiles.columns]

    # Add global mean for comparison
    profiles["global_mean"] = df[all_cols].mean()

    profiles.to_csv(OUTPUT_DIR / "cluster_profiles.csv")
    print(f"[profiling] Profiled {df['cluster_id'].nunique()} clusters across {len(all_cols)} metrics")
    return profiles


def distinguishing_features(df: pd.DataFrame, cluster_id: int, top_n: int = 10) -> pd.DataFrame:
    """
    Find the features where a specific cluster differs most from the global mean.
    """
    num_cols = [c for c in get_numeric_columns() if c in df.columns]
    extra = [c for c in df.columns if c.endswith("_index")]
    all_cols = sorted(set(num_cols + extra) & set(df.columns))

    global_mean = df[all_cols].mean()
    global_std = df[all_cols].std().replace(0, 1)
    cluster_mean = df[df["cluster_id"] == cluster_id][all_cols].mean()

    z_diff = ((cluster_mean - global_mean) / global_std).sort_values(key=abs, ascending=False)

    result = pd.DataFrame({
        "feature": z_diff.index[:top_n],
        "z_diff": z_diff.values[:top_n],
        "cluster_mean": cluster_mean[z_diff.index[:top_n]].values,
        "global_mean": global_mean[z_diff.index[:top_n]].values,
    })
    return result


def cluster_summary_report(df: pd.DataFrame) -> str:
    """Generate a text summary of all clusters."""
    lines = ["=" * 60, "STUDENT ARCHETYPE PROFILES", "=" * 60, ""]

    for cid in sorted(df["cluster_id"].unique()):
        cluster_df = df[df["cluster_id"] == cid]
        n = len(cluster_df)
        pct = n / len(df) * 100

        dist = distinguishing_features(df, cid, top_n=5)
        top_pos = dist[dist["z_diff"] > 0].head(3)
        top_neg = dist[dist["z_diff"] < 0].head(3)

        lines.append(f"--- Cluster {cid} ({n:,} rows, {pct:.1f}%) ---")
        if len(top_pos) > 0:
            lines.append("  HIGH: " + ", ".join(
                f"{r['feature']} (z={r['z_diff']:+.2f})" for _, r in top_pos.iterrows()
            ))
        if len(top_neg) > 0:
            lines.append("  LOW:  " + ", ".join(
                f"{r['feature']} (z={r['z_diff']:+.2f})" for _, r in top_neg.iterrows()
            ))

        # Retention rate
        if "retained_next_term" in cluster_df.columns:
            ret = cluster_df["retained_next_term"].mean()
            lines.append(f"  Retention: {ret:.1%}")
        lines.append("")

    report = "\n".join(lines)
    with open(OUTPUT_DIR / "cluster_summary.txt", "w") as f:
        f.write(report)
    print(report)
    return report
