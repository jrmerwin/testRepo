"""
Clustering: discover student archetypes via K-Means.

Validates against the known generation archetypes.
Uses silhouette score to select optimal k.
"""
import pandas as pd
import numpy as np
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import silhouette_score
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from config.settings import CLUSTER_RANGE, OUTPUT_DIR, get_numeric_columns


def find_optimal_clusters(df: pd.DataFrame, k_range=CLUSTER_RANGE) -> dict:
    """
    Run K-Means for a range of k, return silhouette scores and best k.
    """
    num_cols = [c for c in get_numeric_columns() if c in df.columns]
    data = df[num_cols].apply(pd.to_numeric, errors="coerce").fillna(0)
    data = data.loc[:, data.std() > 0]

    scaler = StandardScaler()
    scaled = scaler.fit_transform(data)

    # Subsample for speed if large
    if len(scaled) > 30_000:
        rng = np.random.default_rng(42)
        idx = rng.choice(len(scaled), 30_000, replace=False)
        scaled_sub = scaled[idx]
    else:
        scaled_sub = scaled

    results = []
    for k in k_range:
        km = KMeans(n_clusters=k, n_init=10, random_state=42, max_iter=200)
        labels = km.fit_predict(scaled_sub)
        sil = silhouette_score(scaled_sub, labels, sample_size=min(5000, len(scaled_sub)))
        inertia = km.inertia_
        results.append({"k": k, "silhouette": sil, "inertia": inertia})
        print(f"  k={k}: silhouette={sil:.4f}, inertia={inertia:.0f}")

    results_df = pd.DataFrame(results)
    best_k = results_df.loc[results_df["silhouette"].idxmax(), "k"]
    print(f"[clustering] Best k={best_k} (silhouette={results_df['silhouette'].max():.4f})")

    # Plot
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))
    ax1.plot(results_df["k"], results_df["silhouette"], "bo-")
    ax1.axvline(best_k, ls="--", color="red", alpha=0.5)
    ax1.set_xlabel("k")
    ax1.set_ylabel("Silhouette Score")
    ax1.set_title("Silhouette Score vs k")

    ax2.plot(results_df["k"], results_df["inertia"], "go-")
    ax2.axvline(best_k, ls="--", color="red", alpha=0.5)
    ax2.set_xlabel("k")
    ax2.set_ylabel("Inertia")
    ax2.set_title("Elbow Plot")
    plt.tight_layout()
    fig.savefig(OUTPUT_DIR / "clustering_selection.png", dpi=150)
    plt.close()

    results_df.to_csv(OUTPUT_DIR / "clustering_scores.csv", index=False)
    return {"results": results_df, "best_k": int(best_k)}


def run_clustering(df: pd.DataFrame, k: int = 8) -> pd.DataFrame:
    """
    Run K-Means with chosen k on the full dataset.
    Returns the input df with a 'cluster_id' column appended.
    """
    num_cols = [c for c in get_numeric_columns() if c in df.columns]
    data = df[num_cols].apply(pd.to_numeric, errors="coerce").fillna(0)
    data = data.loc[:, data.std() > 0]

    scaler = StandardScaler()
    scaled = scaler.fit_transform(data)

    km = KMeans(n_clusters=k, n_init=20, random_state=42)
    df = df.copy()
    df["cluster_id"] = km.fit_predict(scaled)

    print(f"[clustering] Assigned {k} clusters to {len(df):,} rows")
    print(df["cluster_id"].value_counts().sort_index().to_string())

    return df, km, scaler


def validate_clusters(df: pd.DataFrame) -> pd.DataFrame:
    """
    Cross-tab discovered clusters vs true archetypes (synthetic data only).
    """
    if "archetype_true" not in df.columns or "cluster_id" not in df.columns:
        print("[clustering] Cannot validate: missing archetype_true or cluster_id")
        return pd.DataFrame()

    ct = pd.crosstab(df["archetype_true"], df["cluster_id"], normalize="index")
    ct.to_csv(OUTPUT_DIR / "cluster_archetype_crosstab.csv")
    print("[clustering] Archetype × Cluster cross-tab:")
    print(ct.round(2).to_string())
    return ct
