"""
PCA: identify independent dimensions of student variation.

Target: 5-8 components explaining 70%+ of variance.
"""
import pandas as pd
import numpy as np
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from config.settings import PCA_N_COMPONENTS, OUTPUT_DIR, get_numeric_columns


def run_pca(df: pd.DataFrame, n_components: int = PCA_N_COMPONENTS) -> dict:
    """
    Run PCA on the canonical table's numeric features.

    Returns dict with: pca_model, scaler, transformed, loadings, explained_variance.
    """
    num_cols = [c for c in get_numeric_columns() if c in df.columns]
    # Also include engineered features
    extra = [c for c in df.columns if c.endswith("_index") or c.endswith("_lag1") or c.endswith("_lag2")]
    all_cols = list(set(num_cols + extra))
    all_cols = [c for c in all_cols if c in df.columns]

    data = df[all_cols].apply(pd.to_numeric, errors="coerce").fillna(0)

    # Remove zero-variance columns
    data = data.loc[:, data.std() > 0]
    feature_names = list(data.columns)

    scaler = StandardScaler()
    scaled = scaler.fit_transform(data)

    n_comp = min(n_components, len(feature_names), len(data))
    pca = PCA(n_components=n_comp)
    transformed = pca.fit_transform(scaled)

    loadings = pd.DataFrame(
        pca.components_.T,
        index=feature_names,
        columns=[f"PC{i+1}" for i in range(n_comp)],
    )

    explained = pd.DataFrame({
        "component": [f"PC{i+1}" for i in range(n_comp)],
        "explained_variance_ratio": pca.explained_variance_ratio_,
        "cumulative": np.cumsum(pca.explained_variance_ratio_),
    })

    print(f"[PCA] {n_comp} components explain {explained['cumulative'].iloc[-1]:.1%} of variance")
    print(f"[PCA] Components for 70%: {(explained['cumulative'] >= 0.70).idxmax() + 1}")

    # Save outputs
    loadings.to_csv(OUTPUT_DIR / "pca_loadings.csv")
    explained.to_csv(OUTPUT_DIR / "pca_explained_variance.csv", index=False)

    # Scree plot
    fig, ax = plt.subplots(figsize=(10, 5))
    ax.bar(explained["component"], explained["explained_variance_ratio"], alpha=0.6, label="Individual")
    ax.plot(explained["component"], explained["cumulative"], "ro-", label="Cumulative")
    ax.axhline(0.7, ls="--", color="gray", alpha=0.5)
    ax.set_ylabel("Explained Variance Ratio")
    ax.set_title("PCA Scree Plot — Student Variation Dimensions")
    ax.legend()
    plt.tight_layout()
    fig.savefig(OUTPUT_DIR / "pca_scree_plot.png", dpi=150)
    plt.close()

    return {
        "pca_model": pca,
        "scaler": scaler,
        "transformed": transformed,
        "loadings": loadings,
        "explained_variance": explained,
        "feature_names": feature_names,
    }


def top_loadings(loadings: pd.DataFrame, component: str = "PC1", n: int = 10) -> pd.DataFrame:
    """Return the top N features by absolute loading for a given component."""
    return (
        loadings[component]
        .abs()
        .sort_values(ascending=False)
        .head(n)
        .to_frame("abs_loading")
        .assign(raw_loading=lambda x: loadings.loc[x.index, component])
    )
