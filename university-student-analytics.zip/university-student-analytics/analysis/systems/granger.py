"""
Granger causality: directed causal edge detection.

Tests whether lagged values of X improve prediction of Y beyond
Y's own lagged values. Uses panel data by aggregating across students
(mean per term) or running per-student where trajectories are long enough.
"""
import pandas as pd
import numpy as np
from statsmodels.tsa.stattools import grangercausalitytests
import warnings
from config.settings import OUTPUT_DIR, GRANGER_MAX_LAG

# Key variable pairs to test (source → target)
GRANGER_PAIRS = [
    # Engagement → Academic
    ("lms_logins_per_week", "term_gpa"),
    ("assignment_submission_rate", "term_gpa"),
    ("video_watch_pct", "term_gpa"),
    # Support → Academic
    ("advisor_contacts", "term_gpa"),
    ("tutoring_sessions", "term_gpa"),
    ("early_alert_count", "term_gpa"),
    # Financial → Retention
    ("tuition_balance", "retained_next_term"),
    ("financial_aid_pct", "retained_next_term"),
    ("payment_on_time", "retained_next_term"),
    # Academic → Retention
    ("term_gpa", "retained_next_term"),
    ("credit_completion_rate", "retained_next_term"),
    # Engagement → Retention
    ("lms_logins_per_week", "retained_next_term"),
    ("engagement_index", "retained_next_term"),
    # Communication → Engagement
    ("email_open_rate", "lms_logins_per_week"),
    # Support → Retention (intervention effects)
    ("advisor_initiated", "retained_next_term"),
    ("tutoring_sessions", "retained_next_term"),
    # Cascade: GPA → Engagement
    ("term_gpa", "lms_logins_per_week"),
    # Financial stress cascade
    ("tuition_balance", "credits_attempted"),
]


def run_granger_tests(
    df: pd.DataFrame,
    pairs: list = None,
    max_lag: int = GRANGER_MAX_LAG,
    method: str = "aggregate",
) -> pd.DataFrame:
    """
    Run Granger causality tests for specified variable pairs.

    Parameters
    ----------
    df : Canonical DataFrame.
    pairs : List of (cause, effect) tuples.
    max_lag : Maximum lag to test.
    method : 'aggregate' averages across students per term,
             'panel' runs per student (needs long trajectories).

    Returns
    -------
    DataFrame with test results (p-values, F-stats).
    """
    pairs = pairs or GRANGER_PAIRS
    results = []

    if method == "aggregate":
        # Aggregate to term-level means
        agg_cols = list(set(col for pair in pairs for col in pair))
        agg_cols = [c for c in agg_cols if c in df.columns]
        ts = df.groupby("term_code")[agg_cols].mean().sort_index()

        for cause, effect in pairs:
            if cause not in ts.columns or effect not in ts.columns:
                continue
            data = ts[[effect, cause]].dropna()
            if len(data) < max_lag + 3:
                continue
            try:
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore")
                    test = grangercausalitytests(data, maxlag=max_lag, verbose=False)
                for lag in range(1, max_lag + 1):
                    f_stat = test[lag][0]["ssr_ftest"][0]
                    p_val = test[lag][0]["ssr_ftest"][1]
                    results.append({
                        "cause": cause, "effect": effect,
                        "lag": lag, "f_statistic": round(f_stat, 4),
                        "p_value": round(p_val, 6),
                        "significant_05": p_val < 0.05,
                        "significant_01": p_val < 0.01,
                        "method": "aggregate",
                    })
            except Exception as e:
                results.append({
                    "cause": cause, "effect": effect,
                    "lag": 0, "f_statistic": np.nan,
                    "p_value": np.nan, "significant_05": False,
                    "significant_01": False, "method": "aggregate",
                    "error": str(e),
                })

    elif method == "panel":
        # Run per student, aggregate p-values via Fisher's method
        for cause, effect in pairs:
            if cause not in df.columns or effect not in df.columns:
                continue
            student_pvals = []
            for sid, group in df.groupby("student_id"):
                data = group[[effect, cause]].dropna()
                if len(data) < max_lag + 4:
                    continue
                try:
                    with warnings.catch_warnings():
                        warnings.simplefilter("ignore")
                        test = grangercausalitytests(data, maxlag=max_lag, verbose=False)
                    for lag in range(1, max_lag + 1):
                        student_pvals.append(test[lag][0]["ssr_ftest"][1])
                except:
                    pass
            if student_pvals:
                # Fisher's combined p-value
                from scipy.stats import combine_pvalues
                _, combined_p = combine_pvalues(student_pvals[:200], method="fisher")
                results.append({
                    "cause": cause, "effect": effect,
                    "lag": "combined", "f_statistic": np.nan,
                    "p_value": round(combined_p, 6),
                    "significant_05": combined_p < 0.05,
                    "significant_01": combined_p < 0.01,
                    "method": "panel_fisher",
                    "n_students_tested": len(student_pvals),
                })

    results_df = pd.DataFrame(results)
    results_df.to_csv(OUTPUT_DIR / "granger_causality.csv", index=False)

    sig = results_df[results_df["significant_05"] == True]
    print(f"[granger] Tested {len(pairs)} pairs → {len(sig)} significant edges (p<0.05)")
    if len(sig) > 0:
        print(sig[["cause", "effect", "lag", "p_value"]].to_string(index=False))
    return results_df
