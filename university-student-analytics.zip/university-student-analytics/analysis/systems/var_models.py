"""
VAR impulse response models: intervention modeling per archetype.

Fits Vector Autoregression models to each student archetype's time series,
then computes impulse response functions to estimate how shocks to
intervention variables propagate to outcomes.
"""
import pandas as pd
import numpy as np
from statsmodels.tsa.api import VAR
import warnings
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from config.settings import OUTPUT_DIR, VAR_MAX_LAG

# Variables for the VAR system
VAR_VARIABLES = [
    "term_gpa", "lms_logins_per_week", "advisor_contacts",
    "tutoring_sessions", "tuition_balance", "financial_aid_pct",
    "retained_next_term", "early_alert_count",
]


def fit_var_by_archetype(
    df: pd.DataFrame,
    cluster_col: str = "cluster_id",
    variables: list = None,
    max_lag: int = VAR_MAX_LAG,
) -> dict:
    """
    Fit a VAR model for each student archetype.

    Aggregates student-term data to term-level means within each cluster,
    then fits a VAR model.

    Returns dict: {cluster_id: {model, irf, summary}}.
    """
    variables = variables or [v for v in VAR_VARIABLES if v in df.columns]
    results = {}

    for cid in sorted(df[cluster_col].unique()):
        cluster_df = df[df[cluster_col] == cid]

        # Aggregate to term means
        ts = cluster_df.groupby("term_code")[variables].mean().sort_index()
        ts = ts.dropna(axis=1, how="all").dropna()

        if len(ts) < max_lag + 3 or ts.shape[1] < 2:
            print(f"  Cluster {cid}: insufficient data ({len(ts)} terms, {ts.shape[1]} vars), skipping")
            continue

        try:
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                model = VAR(ts)
                fitted = model.fit(maxlags=max_lag, ic="aic")

                # Impulse response for 5 periods ahead
                irf = fitted.irf(periods=5)

            results[cid] = {
                "model": fitted,
                "irf": irf,
                "variables": list(ts.columns),
                "n_terms": len(ts),
                "lag_order": fitted.k_ar,
                "aic": fitted.aic,
            }
            print(f"  Cluster {cid}: VAR({fitted.k_ar}), AIC={fitted.aic:.2f}, vars={list(ts.columns)}")

        except Exception as e:
            print(f"  Cluster {cid}: VAR failed — {e}")

    return results


def compute_intervention_effects(var_results: dict) -> pd.DataFrame:
    """
    Extract impulse response values for key intervention → outcome paths.

    For each cluster, computes the effect of a +1σ shock to intervention
    variables on outcome variables at horizons 1-5.
    """
    interventions = ["advisor_contacts", "tutoring_sessions", "financial_aid_pct"]
    outcomes = ["term_gpa", "retained_next_term"]

    records = []
    for cid, res in var_results.items():
        irf = res["irf"]
        var_names = res["variables"]

        for iv in interventions:
            if iv not in var_names:
                continue
            iv_idx = var_names.index(iv)

            for ov in outcomes:
                if ov not in var_names:
                    continue
                ov_idx = var_names.index(ov)

                # IRF values: irf.irfs[horizon][response_var, impulse_var]
                for h in range(1, 6):
                    try:
                        effect = float(irf.irfs[h][ov_idx, iv_idx])
                        records.append({
                            "cluster_id": cid,
                            "intervention": iv,
                            "outcome": ov,
                            "horizon": h,
                            "impulse_response": round(effect, 6),
                        })
                    except (IndexError, KeyError):
                        pass

    effects_df = pd.DataFrame(records)
    effects_df.to_csv(OUTPUT_DIR / "var_impulse_responses.csv", index=False)
    print(f"[VAR] Computed {len(records)} impulse response values across {len(var_results)} clusters")
    return effects_df


def plot_irf_by_cluster(var_results: dict, intervention: str = "advisor_contacts"):
    """Plot impulse response functions for a given intervention across clusters."""
    outcomes = ["term_gpa", "retained_next_term"]
    n_clusters = len(var_results)
    if n_clusters == 0:
        return

    fig, axes = plt.subplots(n_clusters, len(outcomes), figsize=(12, 3 * n_clusters), squeeze=False)

    for row, (cid, res) in enumerate(sorted(var_results.items())):
        irf = res["irf"]
        var_names = res["variables"]
        if intervention not in var_names:
            continue
        iv_idx = var_names.index(intervention)

        for col, ov in enumerate(outcomes):
            ax = axes[row][col]
            if ov not in var_names:
                ax.set_visible(False)
                continue
            ov_idx = var_names.index(ov)

            responses = [float(irf.irfs[h][ov_idx, iv_idx]) for h in range(6)]
            ax.bar(range(6), responses, color="steelblue", alpha=0.7)
            ax.axhline(0, color="black", linewidth=0.5)
            ax.set_title(f"Cluster {cid}: {intervention}→{ov}")
            ax.set_xlabel("Horizon (terms)")
            ax.set_ylabel("Response")

    plt.suptitle(f"Impulse Response: +1σ {intervention}", fontsize=14, y=1.01)
    plt.tight_layout()
    fig.savefig(OUTPUT_DIR / f"irf_{intervention}.png", dpi=150, bbox_inches="tight")
    plt.close()
    print(f"[VAR] IRF plot saved for {intervention}")
