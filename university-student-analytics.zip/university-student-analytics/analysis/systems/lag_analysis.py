"""
Lag analysis: identify leading indicators of outcomes.

Tests whether signals at t-k predict outcomes at t, using
cross-correlation at multiple lag values.
"""
import pandas as pd
import numpy as np
from config.settings import OUTPUT_DIR, GRANGER_MAX_LAG


# Key predictors to test against outcomes
PREDICTOR_COLS = [
    "term_gpa", "lms_logins_per_week", "assignment_submission_rate",
    "tuition_balance", "financial_aid_pct", "payment_on_time",
    "advisor_contacts", "early_alert_count", "tutoring_sessions",
    "email_open_rate", "engagement_index", "financial_stress_index",
    "academic_momentum_index", "video_watch_pct", "last_login_days_ago",
]

OUTCOME_COLS = [
    "retained_next_term", "term_gpa", "stopped_out",
]


def compute_lagged_correlations(
    df: pd.DataFrame,
    predictors: list = None,
    outcomes: list = None,
    max_lag: int = GRANGER_MAX_LAG,
) -> pd.DataFrame:
    """
    For each predictor × outcome pair, compute correlation at lags 0..max_lag.

    Returns a DataFrame with columns: predictor, outcome, lag, correlation.
    """
    predictors = predictors or [c for c in PREDICTOR_COLS if c in df.columns]
    outcomes = outcomes or [c for c in OUTCOME_COLS if c in df.columns]

    df = df.sort_values(["student_id", "term_code"]).copy()

    results = []
    for pred in predictors:
        for outcome in outcomes:
            if pred == outcome:
                continue
            for lag in range(0, max_lag + 1):
                # Shift predictor back by `lag` terms within each student
                lagged = df.groupby("student_id")[pred].shift(lag)
                valid = lagged.notna() & df[outcome].notna()
                if valid.sum() < 100:
                    continue
                r = lagged[valid].corr(df[outcome][valid])
                results.append({
                    "predictor": pred, "outcome": outcome,
                    "lag": lag, "correlation": round(r, 4),
                    "n_obs": int(valid.sum()),
                })

    results_df = pd.DataFrame(results)
    results_df["abs_corr"] = results_df["correlation"].abs()
    results_df.sort_values("abs_corr", ascending=False, inplace=True)

    results_df.to_csv(OUTPUT_DIR / "lagged_correlations.csv", index=False)
    print(f"[lag_analysis] Computed {len(results_df)} predictor×outcome×lag combinations")
    return results_df


def find_leading_indicators(lag_df: pd.DataFrame, min_improvement: float = 0.05) -> pd.DataFrame:
    """
    Identify predictors where lagged correlation is stronger than contemporaneous.
    These are true leading indicators.
    """
    records = []
    for (pred, outcome), group in lag_df.groupby(["predictor", "outcome"]):
        lag0 = group[group["lag"] == 0]["abs_corr"].values
        if len(lag0) == 0:
            continue
        lag0_val = lag0[0]

        for _, row in group[group["lag"] > 0].iterrows():
            improvement = row["abs_corr"] - lag0_val
            if improvement > min_improvement:
                records.append({
                    "predictor": pred,
                    "outcome": outcome,
                    "best_lag": row["lag"],
                    "lagged_corr": row["correlation"],
                    "contemporaneous_corr": lag0_val * np.sign(row["correlation"]),
                    "improvement": round(improvement, 4),
                })

    leading = pd.DataFrame(records).sort_values("improvement", ascending=False)
    leading.to_csv(OUTPUT_DIR / "leading_indicators.csv", index=False)
    print(f"[lag_analysis] Found {len(leading)} leading indicators")
    if len(leading) > 0:
        print(leading.head(10).to_string(index=False))
    return leading
