"""
Systems graph: construct a formal causal map from Granger causality results.

Builds a directed graph where edges represent statistically significant
Granger-causal relationships. Computes centrality metrics and identifies
key leverage points for intervention.
"""
import pandas as pd
import numpy as np
import networkx as nx
import json
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from config.settings import OUTPUT_DIR


def build_systems_graph(
    granger_df: pd.DataFrame,
    corr_df: pd.DataFrame = None,
    p_threshold: float = 0.05,
) -> nx.DiGraph:
    """
    Build a directed graph from significant Granger causality results.

    Parameters
    ----------
    granger_df : Results from run_granger_tests.
    corr_df : Optional correlation matrix for edge weights.
    p_threshold : Significance threshold.

    Returns
    -------
    networkx DiGraph with causal edges.
    """
    G = nx.DiGraph()

    sig = granger_df[granger_df["p_value"] < p_threshold].copy()

    # For each cause→effect pair, use the best (lowest p) lag
    best = sig.groupby(["cause", "effect"]).agg(
        best_p=("p_value", "min"),
        best_lag=("lag", "first"),
        best_f=("f_statistic", "max"),
    ).reset_index()

    for _, row in best.iterrows():
        weight = -np.log10(max(row["best_p"], 1e-10))  # higher = more significant
        G.add_edge(
            row["cause"], row["effect"],
            p_value=row["best_p"],
            lag=row["best_lag"],
            f_stat=row["best_f"],
            weight=weight,
        )

    print(f"[systems_graph] Built graph: {G.number_of_nodes()} nodes, {G.number_of_edges()} edges")

    # Compute centrality metrics
    if G.number_of_nodes() > 0:
        in_deg = dict(G.in_degree())
        out_deg = dict(G.out_degree())
        try:
            betweenness = nx.betweenness_centrality(G)
        except:
            betweenness = {n: 0 for n in G.nodes()}
        try:
            pagerank = nx.pagerank(G, alpha=0.85)
        except:
            pagerank = {n: 1 / G.number_of_nodes() for n in G.nodes()}

        centrality = pd.DataFrame({
            "node": list(G.nodes()),
            "in_degree": [in_deg.get(n, 0) for n in G.nodes()],
            "out_degree": [out_deg.get(n, 0) for n in G.nodes()],
            "betweenness": [betweenness.get(n, 0) for n in G.nodes()],
            "pagerank": [pagerank.get(n, 0) for n in G.nodes()],
        }).sort_values("pagerank", ascending=False)

        centrality.to_csv(OUTPUT_DIR / "node_centrality.csv", index=False)
        print("[systems_graph] Node centrality:")
        print(centrality.head(10).to_string(index=False))

    return G


def export_graph(G: nx.DiGraph):
    """Export graph to multiple formats."""
    # Edge list
    edges = []
    for u, v, data in G.edges(data=True):
        edges.append({"source": u, "target": v, **data})
    pd.DataFrame(edges).to_csv(OUTPUT_DIR / "systems_graph_edges.csv", index=False)

    # JSON for visualization
    graph_data = nx.node_link_data(G)
    with open(OUTPUT_DIR / "systems_graph.json", "w") as f:
        json.dump(graph_data, f, indent=2, default=str)

    print(f"[systems_graph] Exported to CSV and JSON")


def plot_systems_graph(G: nx.DiGraph):
    """Visualize the causal systems graph."""
    if G.number_of_nodes() == 0:
        print("[systems_graph] Empty graph, skipping plot")
        return

    fig, ax = plt.subplots(figsize=(16, 12))
    pos = nx.spring_layout(G, k=2, iterations=50, seed=42)

    # Node sizes by PageRank
    try:
        pr = nx.pagerank(G)
        sizes = [pr.get(n, 0.01) * 5000 for n in G.nodes()]
    except:
        sizes = [300] * G.number_of_nodes()

    # Edge widths by significance
    widths = [G[u][v].get("weight", 1) * 0.5 for u, v in G.edges()]

    nx.draw_networkx_nodes(G, pos, node_size=sizes, node_color="steelblue", alpha=0.7, ax=ax)
    nx.draw_networkx_edges(G, pos, width=widths, alpha=0.5, edge_color="gray",
                           arrows=True, arrowsize=15, ax=ax)
    nx.draw_networkx_labels(G, pos, font_size=8, ax=ax)

    ax.set_title("Student Experience Causal Systems Graph")
    ax.axis("off")
    plt.tight_layout()
    fig.savefig(OUTPUT_DIR / "systems_graph.png", dpi=150, bbox_inches="tight")
    plt.close()
    print("[systems_graph] Graph visualization saved")


def find_intervention_targets(G: nx.DiGraph) -> pd.DataFrame:
    """
    Identify high-leverage intervention targets:
    nodes with high out-degree (influence many outcomes)
    and that are controllable (support/intervention variables).
    """
    controllable = {
        "advisor_contacts", "advisor_initiated", "tutoring_sessions",
        "early_alert_count", "mentoring_program", "financial_aid_pct",
        "scholarship_amount", "payment_plan_active",
    }

    targets = []
    for node in G.nodes():
        out_d = G.out_degree(node)
        in_d = G.in_degree(node)
        is_ctrl = node in controllable

        # Count downstream reachable nodes
        try:
            reachable = len(nx.descendants(G, node))
        except:
            reachable = 0

        targets.append({
            "variable": node,
            "out_degree": out_d,
            "in_degree": in_d,
            "reachable_nodes": reachable,
            "controllable": is_ctrl,
            "leverage_score": out_d * (2 if is_ctrl else 1) + reachable,
        })

    targets_df = pd.DataFrame(targets).sort_values("leverage_score", ascending=False)
    targets_df.to_csv(OUTPUT_DIR / "intervention_targets.csv", index=False)
    print("[systems_graph] Intervention targets:")
    print(targets_df[targets_df["controllable"]].head(10).to_string(index=False))
    return targets_df
