"""
Markov transition dynamics: archetype stability and tipping points.

Computes term-to-term transition probabilities between student clusters,
identifies stable vs unstable archetypes, and detects tipping-point
patterns (e.g., disengaging → stopout flows).
"""
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
from config.settings import OUTPUT_DIR


def compute_transition_matrix(df: pd.DataFrame, state_col: str = "cluster_id") -> pd.DataFrame:
    """
    Compute the Markov transition matrix from term-to-term cluster changes.

    Returns a square DataFrame: rows = from-state, columns = to-state,
    values = P(to | from).
    """
    df = df.sort_values(["student_id", "term_code"]).copy()
    df["next_state"] = df.groupby("student_id")[state_col].shift(-1)

    # Add terminal states
    df.loc[df["active_status"] == "graduated", "next_state"] = "graduated"
    df.loc[df["active_status"] == "withdrawn", "next_state"] = "withdrawn"
    df.loc[df["stopped_out"] == 1, "next_state"] = "stopped_out"

    # Drop rows without next state
    transitions = df.dropna(subset=["next_state"])
    transitions[state_col] = transitions[state_col].astype(str)
    transitions["next_state"] = transitions["next_state"].astype(str)

    # Count transitions
    ct = pd.crosstab(transitions[state_col], transitions["next_state"])

    # Normalize to probabilities
    trans_matrix = ct.div(ct.sum(axis=1), axis=0).fillna(0)

    trans_matrix.to_csv(OUTPUT_DIR / "transition_matrix.csv")
    print(f"[markov] Transition matrix: {trans_matrix.shape[0]} states")
    return trans_matrix


def analyze_stability(trans_matrix: pd.DataFrame) -> pd.DataFrame:
    """
    Classify each state as stable, source, or sink based on self-transition
    probability and flow patterns.
    """
    records = []
    for state in trans_matrix.index:
        if state in trans_matrix.columns:
            self_prob = trans_matrix.loc[state, state]
        else:
            self_prob = 0

        # Out-flow to terminal states
        outflow_terminal = 0
        for terminal in ["withdrawn", "stopped_out", "graduated"]:
            if terminal in trans_matrix.columns:
                outflow_terminal += trans_matrix.loc[state, terminal] if state != terminal else 0

        # In-flow (how many states transition INTO this state)
        if state in trans_matrix.columns:
            inflow = trans_matrix[state].sum() - (trans_matrix.loc[state, state] if state in trans_matrix.index else 0)
        else:
            inflow = 0

        # Classification
        if self_prob > 0.6:
            classification = "stable"
        elif outflow_terminal > 0.3:
            classification = "source (feeds terminal)"
        elif inflow > 1.0:
            classification = "sink (absorbs students)"
        else:
            classification = "transient"

        records.append({
            "state": state,
            "self_transition_prob": round(self_prob, 4),
            "outflow_to_terminal": round(outflow_terminal, 4),
            "inflow_from_others": round(inflow, 4),
            "classification": classification,
        })

    stability = pd.DataFrame(records).sort_values("self_transition_prob", ascending=False)
    stability.to_csv(OUTPUT_DIR / "archetype_stability.csv", index=False)
    print("[markov] Archetype stability:")
    print(stability.to_string(index=False))
    return stability


def steady_state_distribution(trans_matrix: pd.DataFrame) -> pd.Series:
    """
    Compute the steady-state (stationary) distribution of the Markov chain.
    This predicts the long-run proportion of students in each state.
    """
    # Filter to states that appear in both rows and columns
    common = list(set(trans_matrix.index) & set(trans_matrix.columns))
    T = trans_matrix.loc[common, common].values

    # Normalize rows
    row_sums = T.sum(axis=1, keepdims=True)
    row_sums[row_sums == 0] = 1
    T = T / row_sums

    # Eigenvalue decomposition: stationary distribution is left eigenvector with eigenvalue 1
    eigenvalues, eigenvectors = np.linalg.eig(T.T)
    idx = np.argmin(np.abs(eigenvalues - 1.0))
    stationary = np.real(eigenvectors[:, idx])
    stationary = stationary / stationary.sum()

    result = pd.Series(stationary, index=common).sort_values(ascending=False)
    result.to_csv(OUTPUT_DIR / "steady_state_distribution.csv", header=["probability"])
    print("[markov] Steady-state distribution:")
    for state, prob in result.items():
        print(f"  {state}: {prob:.4f}")
    return result


def plot_transition_heatmap(trans_matrix: pd.DataFrame):
    """Visualize the transition matrix as a heatmap."""
    fig, ax = plt.subplots(figsize=(10, 8))
    sns.heatmap(trans_matrix, annot=True, fmt=".2f", cmap="YlOrRd",
                square=True, ax=ax, vmin=0, vmax=1)
    ax.set_title("Archetype Transition Matrix")
    ax.set_ylabel("From State")
    ax.set_xlabel("To State")
    plt.tight_layout()
    fig.savefig(OUTPUT_DIR / "transition_heatmap.png", dpi=150)
    plt.close()
    print("[markov] Transition heatmap saved")
