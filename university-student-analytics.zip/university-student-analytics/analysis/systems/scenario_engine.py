"""
Scenario engine: "what happens if we intervene with X for archetype Y?"

Combines VAR impulse responses, transition matrices, and cluster sizes
to estimate the population-level impact of interventions.
"""
import pandas as pd
import numpy as np
from config.settings import OUTPUT_DIR


class ScenarioEngine:
    """
    Run intervention scenarios using VAR impulse responses and Markov transitions.
    """

    def __init__(
        self,
        irf_df: pd.DataFrame,
        transition_matrix: pd.DataFrame,
        cluster_sizes: pd.Series,
    ):
        """
        Parameters
        ----------
        irf_df : DataFrame from compute_intervention_effects (VAR IRF values).
        transition_matrix : Markov transition matrix.
        cluster_sizes : Series mapping cluster_id → number of students.
        """
        self.irf = irf_df
        self.transitions = transition_matrix
        self.cluster_sizes = cluster_sizes
        self.total_students = cluster_sizes.sum()

    def run_scenario(
        self,
        intervention: str,
        target_clusters: list = None,
        shock_size: float = 1.0,
        horizon: int = 3,
    ) -> dict:
        """
        Estimate the impact of an intervention on retention.

        Parameters
        ----------
        intervention : Variable name (e.g., 'advisor_contacts').
        target_clusters : List of cluster IDs to target (None = all).
        shock_size : Magnitude of intervention in standard deviations.
        horizon : Number of terms to project.

        Returns
        -------
        Dict with scenario summary and per-cluster effects.
        """
        if target_clusters is None:
            target_clusters = list(self.cluster_sizes.index)

        # Filter IRF data for this intervention
        irf_sub = self.irf[
            (self.irf["intervention"] == intervention) &
            (self.irf["outcome"] == "retained_next_term") &
            (self.irf["horizon"] <= horizon)
        ]

        cluster_effects = []
        total_additional_retained = 0

        for cid in target_clusters:
            cid_str = str(cid)
            n_students = self.cluster_sizes.get(cid, self.cluster_sizes.get(int(cid), 0))
            if n_students == 0:
                continue

            # Get cumulative IRF effect for this cluster
            cluster_irf = irf_sub[irf_sub["cluster_id"].astype(str) == cid_str]
            if len(cluster_irf) == 0:
                continue

            # Sum impulse responses over horizon (cumulative effect)
            cumulative_effect = cluster_irf["impulse_response"].sum() * shock_size
            # Convert to retention probability change (bounded)
            retention_boost = np.clip(cumulative_effect, -0.5, 0.5)
            additional_retained = int(round(n_students * abs(retention_boost)))

            cluster_effects.append({
                "cluster_id": cid,
                "n_students": int(n_students),
                "cumulative_irf": round(cumulative_effect, 4),
                "retention_boost": round(retention_boost, 4),
                "additional_retained": additional_retained,
            })
            total_additional_retained += additional_retained

        effects_df = pd.DataFrame(cluster_effects)

        result = {
            "intervention": intervention,
            "shock_size_sd": shock_size,
            "target_clusters": target_clusters,
            "horizon_terms": horizon,
            "total_students_targeted": int(effects_df["n_students"].sum()) if len(effects_df) > 0 else 0,
            "total_additional_retained": total_additional_retained,
            "retention_lift_pct": round(
                total_additional_retained / max(effects_df["n_students"].sum(), 1) * 100, 2
            ) if len(effects_df) > 0 else 0,
            "per_cluster": effects_df,
        }
        return result

    def compare_scenarios(self, scenarios: list) -> pd.DataFrame:
        """
        Run multiple scenarios and compare their impact.

        Parameters
        ----------
        scenarios : List of dicts with keys: intervention, target_clusters, shock_size, horizon.

        Returns
        -------
        Comparison DataFrame.
        """
        results = []
        for i, spec in enumerate(scenarios):
            outcome = self.run_scenario(**spec)
            results.append({
                "scenario": i + 1,
                "intervention": outcome["intervention"],
                "shock_size": outcome["shock_size_sd"],
                "target_clusters": str(outcome["target_clusters"]),
                "students_targeted": outcome["total_students_targeted"],
                "additional_retained": outcome["total_additional_retained"],
                "retention_lift_pct": outcome["retention_lift_pct"],
            })

        comparison = pd.DataFrame(results).sort_values("additional_retained", ascending=False)
        comparison.to_csv(OUTPUT_DIR / "scenario_comparison.csv", index=False)
        return comparison


def run_default_scenarios(irf_df, transition_matrix, cluster_sizes) -> pd.DataFrame:
    """Run a set of standard intervention scenarios."""
    engine = ScenarioEngine(irf_df, transition_matrix, cluster_sizes)

    # Find at-risk clusters (those with low retention in transition matrix)
    at_risk = []
    for state in transition_matrix.index:
        terminal_flow = 0
        for t in ["withdrawn", "stopped_out"]:
            if t in transition_matrix.columns:
                terminal_flow += transition_matrix.loc[state, t]
        if terminal_flow > 0.2:
            try:
                at_risk.append(int(state))
            except ValueError:
                pass

    all_clusters = [c for c in cluster_sizes.index if isinstance(c, (int, np.integer))]

    scenarios = [
        {
            "intervention": "advisor_contacts",
            "target_clusters": at_risk if at_risk else all_clusters[:3],
            "shock_size": 1.0,
            "horizon": 3,
        },
        {
            "intervention": "advisor_contacts",
            "target_clusters": all_clusters,
            "shock_size": 0.5,
            "horizon": 3,
        },
        {
            "intervention": "tutoring_sessions",
            "target_clusters": at_risk if at_risk else all_clusters[:3],
            "shock_size": 1.5,
            "horizon": 3,
        },
        {
            "intervention": "financial_aid_pct",
            "target_clusters": at_risk if at_risk else all_clusters[:3],
            "shock_size": 1.0,
            "horizon": 3,
        },
    ]

    print("=" * 60)
    print("SCENARIO ANALYSIS: Intervention Impact Projections")
    print("=" * 60)

    comparison = engine.compare_scenarios(scenarios)
    print(comparison.to_string(index=False))

    # Detailed output for best scenario
    best = scenarios[comparison["additional_retained"].idxmax()]
    detail = engine.run_scenario(**best)
    print(f"\nBest scenario detail: {detail['intervention']}")
    print(f"  Students targeted: {detail['total_students_targeted']:,}")
    print(f"  Additional retentions: {detail['total_additional_retained']:,}")
    print(f"  Retention lift: {detail['retention_lift_pct']}%")

    return comparison
