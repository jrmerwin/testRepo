"""
Cross-group correlation matrix.

Computes correlations between signal groups and identifies the strongest
cross-group relationships. Uses group-level composite indices when
available, falls back to individual metrics.
"""
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
from config.settings import OUTPUT_DIR, SIGNAL_GROUPS, get_numeric_columns


def compute_correlation_matrix(df: pd.DataFrame) -> pd.DataFrame:
    """
    Compute full correlation matrix on numeric features.
    Returns the correlation DataFrame.
    """
    num_cols = [c for c in get_numeric_columns() if c in df.columns]
    extra = [c for c in df.columns if c.endswith("_index")]
    all_cols = sorted(set(num_cols + extra) & set(df.columns))

    data = df[all_cols].apply(pd.to_numeric, errors="coerce")
    corr = data.corr()

    corr.to_csv(OUTPUT_DIR / "correlation_matrix.csv")
    print(f"[correlation] Computed {len(all_cols)}×{len(all_cols)} correlation matrix")
    return corr


def cross_group_summary(corr: pd.DataFrame) -> pd.DataFrame:
    """
    Summarize average absolute correlation between signal groups.
    """
    group_cols = {}
    for gname, metrics in SIGNAL_GROUPS.items():
        cols = [m for m in metrics if m in corr.columns]
        if cols:
            group_cols[gname] = cols

    groups = list(group_cols.keys())
    summary = pd.DataFrame(index=groups, columns=groups, dtype=float)

    for g1 in groups:
        for g2 in groups:
            if g1 == g2:
                summary.loc[g1, g2] = 1.0
            else:
                sub = corr.loc[group_cols[g1], group_cols[g2]]
                summary.loc[g1, g2] = sub.abs().mean().mean()

    summary.to_csv(OUTPUT_DIR / "cross_group_correlation.csv")
    print("[correlation] Cross-group average |r|:")
    print(summary.round(3).to_string())
    return summary


def strongest_cross_group_pairs(corr: pd.DataFrame, top_n: int = 20) -> pd.DataFrame:
    """Find the strongest cross-group correlations."""
    # Build group membership lookup
    col_to_group = {}
    for gname, metrics in SIGNAL_GROUPS.items():
        for m in metrics:
            if m in corr.columns:
                col_to_group[m] = gname

    pairs = []
    cols = [c for c in corr.columns if c in col_to_group]
    for i, c1 in enumerate(cols):
        for c2 in cols[i + 1:]:
            if col_to_group[c1] != col_to_group[c2]:
                r = corr.loc[c1, c2]
                pairs.append({
                    "feature_1": c1, "group_1": col_to_group[c1],
                    "feature_2": c2, "group_2": col_to_group[c2],
                    "correlation": r, "abs_correlation": abs(r),
                })

    pairs_df = pd.DataFrame(pairs).sort_values("abs_correlation", ascending=False).head(top_n)
    pairs_df.to_csv(OUTPUT_DIR / "top_cross_group_correlations.csv", index=False)
    print(f"[correlation] Top {top_n} cross-group pairs saved")
    return pairs_df


def plot_correlation_heatmap(corr: pd.DataFrame, max_features: int = 30):
    """Plot a heatmap of the top-variance features."""
    # Select most variable features
    if len(corr) > max_features:
        var_order = corr.abs().mean().sort_values(ascending=False).index[:max_features]
        corr = corr.loc[var_order, var_order]

    fig, ax = plt.subplots(figsize=(14, 12))
    sns.heatmap(corr, cmap="RdBu_r", center=0, vmin=-1, vmax=1,
                square=True, ax=ax, cbar_kws={"shrink": 0.8})
    ax.set_title("Feature Correlation Matrix (top features)")
    plt.tight_layout()
    fig.savefig(OUTPUT_DIR / "correlation_heatmap.png", dpi=150)
    plt.close()
    print("[correlation] Heatmap saved")
