"""
Central configuration for the University Student Analytics pipeline.

This is the single source of truth for signal groups, student archetypes,
feature engineering definitions, and pipeline parameters.
"""
from pathlib import Path
import numpy as np

# ── Paths ────────────────────────────────────────────────────────────────────
PROJECT_ROOT = Path(__file__).resolve().parent.parent
DB_PATH = PROJECT_ROOT / "outputs" / "student_analytics.db"
OUTPUT_DIR = PROJECT_ROOT / "outputs"
OUTPUT_DIR.mkdir(exist_ok=True)

# ── Global Parameters ────────────────────────────────────────────────────────
NUM_STUDENTS = 5_000          # Scale down for dev; seed says 50k for prod
NUM_TERMS = 12                # Average terms per student trajectory
RANDOM_SEED = 42
TERM_CODES = [
    "2019FA", "2020SP", "2020SU", "2020FA", "2021SP", "2021SU",
    "2021FA", "2022SP", "2022SU", "2022FA", "2023SP", "2023SU",
    "2023FA", "2024SP", "2024SU", "2024FA", "2025SP",
]
TERM_START_DATES = {
    "2019FA": "2019-08-26", "2020SP": "2020-01-13", "2020SU": "2020-05-11",
    "2020FA": "2020-08-24", "2021SP": "2021-01-11", "2021SU": "2021-05-10",
    "2021FA": "2021-08-23", "2022SP": "2022-01-10", "2022SU": "2022-05-09",
    "2022FA": "2022-08-22", "2023SP": "2023-01-09", "2023SU": "2023-05-08",
    "2023FA": "2023-08-21", "2024SP": "2024-01-08", "2024SU": "2024-05-06",
    "2024FA": "2024-08-19", "2025SP": "2025-01-06",
}

# ── Signal Group Definitions ─────────────────────────────────────────────────
# Each group: dict of metric_name → {type, default, description}

SIGNAL_GROUPS = {
    "academic": {
        "term_gpa":                 {"type": "continuous", "range": (0.0, 4.0)},
        "cumulative_gpa":           {"type": "continuous", "range": (0.0, 4.0)},
        "credits_attempted":        {"type": "integer",    "range": (0, 18)},
        "credits_earned":           {"type": "integer",    "range": (0, 18)},
        "credit_completion_rate":   {"type": "ratio",      "range": (0.0, 1.0)},
        "assignment_avg_score":     {"type": "continuous", "range": (0.0, 100.0)},
        "assignment_submission_rate": {"type": "ratio",    "range": (0.0, 1.0)},
        "failed_courses":           {"type": "integer",    "range": (0, 6)},
        "academic_standing":        {"type": "categorical","categories": ["good","warning","probation","suspension"]},
    },
    "engagement": {
        "lms_logins_per_week":      {"type": "continuous", "range": (0, 50)},
        "lms_session_duration_min": {"type": "continuous", "range": (0, 180)},
        "discussion_posts":         {"type": "integer",    "range": (0, 40)},
        "discussion_replies":       {"type": "integer",    "range": (0, 30)},
        "video_watch_pct":          {"type": "ratio",      "range": (0.0, 1.0)},
        "resource_downloads":       {"type": "integer",    "range": (0, 50)},
        "mobile_vs_desktop_ratio":  {"type": "ratio",      "range": (0.0, 1.0)},
        "last_login_days_ago":      {"type": "integer",    "range": (0, 120)},
        "weekly_login_trend":       {"type": "continuous", "range": (-5, 5)},
    },
    "financial": {
        "tuition_balance":          {"type": "continuous", "range": (0, 15000)},
        "financial_aid_pct":        {"type": "ratio",      "range": (0.0, 1.0)},
        "payment_on_time":          {"type": "boolean",    "range": (0, 1)},
        "payment_plan_active":      {"type": "boolean",    "range": (0, 1)},
        "scholarship_amount":       {"type": "continuous", "range": (0, 10000)},
        "employer_tuition_assist":  {"type": "boolean",    "range": (0, 1)},
        "outstanding_fees":         {"type": "continuous", "range": (0, 2000)},
        "refund_issued":            {"type": "boolean",    "range": (0, 1)},
        "total_lifetime_charges":   {"type": "continuous", "range": (0, 100000)},
    },
    "support": {
        "advisor_contacts":         {"type": "integer",    "range": (0, 15)},
        "advisor_initiated":        {"type": "integer",    "range": (0, 10)},
        "student_initiated":        {"type": "integer",    "range": (0, 10)},
        "tutoring_sessions":        {"type": "integer",    "range": (0, 20)},
        "early_alert_count":        {"type": "integer",    "range": (0, 6)},
        "support_ticket_count":     {"type": "integer",    "range": (0, 10)},
        "accommodation_active":     {"type": "boolean",    "range": (0, 1)},
        "mentoring_program":        {"type": "boolean",    "range": (0, 1)},
        "orientation_completed":    {"type": "boolean",    "range": (0, 1)},
    },
    "demographics": {
        "age":                      {"type": "integer",    "range": (17, 70)},
        "gender":                   {"type": "categorical","categories": ["M","F","Other"]},
        "ethnicity":                {"type": "categorical","categories": ["White","Black","Hispanic","Asian","Other"]},
        "first_generation":         {"type": "boolean",    "range": (0, 1)},
        "prior_education":          {"type": "categorical","categories": ["hs","some_college","associate","bachelor_plus"]},
        "military_status":          {"type": "categorical","categories": ["none","active","veteran","dependent"]},
        "employment_status":        {"type": "categorical","categories": ["full_time","part_time","unemployed"]},
        "dependents":               {"type": "integer",    "range": (0, 6)},
        "years_since_last_education": {"type": "integer",  "range": (0, 30)},
    },
    "program": {
        "program_code":             {"type": "categorical","categories": ["BUS","CS","NURS","EDU","PSYCH","CJ","IT","COMM"]},
        "program_level":            {"type": "categorical","categories": ["associate","bachelor","master","certificate"]},
        "enrollment_status":        {"type": "categorical","categories": ["full_time","half_time","less_than_half"]},
        "enrollment_intensity":     {"type": "ratio",      "range": (0.0, 1.0)},
        "terms_enrolled":           {"type": "integer",    "range": (1, 20)},
        "terms_since_start":        {"type": "integer",    "range": (1, 25)},
        "transfer_credits":         {"type": "integer",    "range": (0, 90)},
        "program_change_count":     {"type": "integer",    "range": (0, 4)},
        "modality":                 {"type": "categorical","categories": ["online","hybrid","in_person"]},
    },
    "course_level": {
        "avg_class_size":           {"type": "continuous", "range": (5, 200)},
        "avg_course_difficulty":    {"type": "continuous", "range": (1.5, 3.8)},
        "pct_courses_with_live_sessions": {"type": "ratio","range": (0.0, 1.0)},
        "instructor_avg_rating":    {"type": "continuous", "range": (1.0, 5.0)},
        "course_format_diversity":  {"type": "integer",    "range": (1, 5)},
        "prerequisite_met_pct":     {"type": "ratio",      "range": (0.0, 1.0)},
        "avg_course_completion_rate": {"type": "ratio",    "range": (0.3, 1.0)},
    },
    "communication": {
        "email_open_rate":          {"type": "ratio",      "range": (0.0, 1.0)},
        "email_click_rate":         {"type": "ratio",      "range": (0.0, 0.5)},
        "survey_response_rate":     {"type": "ratio",      "range": (0.0, 1.0)},
        "last_survey_satisfaction": {"type": "continuous", "range": (1.0, 5.0)},
        "support_ticket_sentiment": {"type": "continuous", "range": (-1.0, 1.0)},
        "complaint_count":          {"type": "integer",    "range": (0, 5)},
        "net_promoter_score":       {"type": "continuous", "range": (-100, 100)},
    },
    "technology": {
        "avg_connection_speed":     {"type": "continuous", "range": (1, 200)},
        "tech_support_tickets":     {"type": "integer",    "range": (0, 10)},
        "device_type":              {"type": "categorical","categories": ["desktop","laptop","tablet","phone"]},
        "browser_diversity":        {"type": "integer",    "range": (1, 5)},
        "proctoring_issues":        {"type": "integer",    "range": (0, 5)},
        "lms_error_rate":           {"type": "ratio",      "range": (0.0, 0.3)},
    },
    "outcomes": {
        "retained_next_term":       {"type": "boolean",    "range": (0, 1)},
        "graduated":                {"type": "boolean",    "range": (0, 1)},
        "stopped_out":              {"type": "boolean",    "range": (0, 1)},
        "time_to_degree_pct":       {"type": "ratio",      "range": (0.0, 2.0)},
        "active_status":            {"type": "categorical","categories": ["active","LOA","withdrawn","graduated","dismissed"]},
    },
}

# ── Student Archetypes (for synthetic generation & clustering validation) ────
ARCHETYPES = {
    "traditional_achiever": {
        "proportion": 0.15,
        "description": "Young, full-time, high GPA, high engagement, strong retention",
        "params": {
            "age_mean": 21, "age_std": 2,
            "gpa_mean": 3.5, "gpa_std": 0.3,
            "engagement_factor": 0.85,
            "financial_aid_pct_mean": 0.7,
            "retention_prob": 0.92,
            "employment": {"full_time": 0.1, "part_time": 0.5, "unemployed": 0.4},
            "first_gen_prob": 0.15,
            "enrollment_status": "full_time",
            "credits_mean": 15, "credits_std": 2,
        },
    },
    "working_adult_steady": {
        "proportion": 0.25,
        "description": "30-45, part-time, moderate GPA, consistent, employer assist",
        "params": {
            "age_mean": 37, "age_std": 6,
            "gpa_mean": 3.0, "gpa_std": 0.4,
            "engagement_factor": 0.55,
            "financial_aid_pct_mean": 0.3,
            "retention_prob": 0.85,
            "employment": {"full_time": 0.7, "part_time": 0.25, "unemployed": 0.05},
            "first_gen_prob": 0.35,
            "enrollment_status": "half_time",
            "credits_mean": 9, "credits_std": 2,
            "employer_assist_prob": 0.45,
        },
    },
    "career_changer_motivated": {
        "proportion": 0.10,
        "description": "28-40, high engagement, high GPA, self-funded, strong retention",
        "params": {
            "age_mean": 34, "age_std": 5,
            "gpa_mean": 3.4, "gpa_std": 0.3,
            "engagement_factor": 0.80,
            "financial_aid_pct_mean": 0.2,
            "retention_prob": 0.90,
            "employment": {"full_time": 0.5, "part_time": 0.35, "unemployed": 0.15},
            "first_gen_prob": 0.20,
            "enrollment_status": "full_time",
            "credits_mean": 12, "credits_std": 3,
        },
    },
    "struggling_first_gen": {
        "proportion": 0.15,
        "description": "First-gen, lower GPA, declining engagement, financial stress, at-risk",
        "params": {
            "age_mean": 24, "age_std": 5,
            "gpa_mean": 2.2, "gpa_std": 0.5,
            "engagement_factor": 0.45,
            "financial_aid_pct_mean": 0.6,
            "retention_prob": 0.65,
            "employment": {"full_time": 0.35, "part_time": 0.45, "unemployed": 0.20},
            "first_gen_prob": 0.90,
            "enrollment_status": "full_time",
            "credits_mean": 12, "credits_std": 3,
            "gpa_trend": -0.08,  # declining per term
        },
    },
    "military_veteran": {
        "proportion": 0.08,
        "description": "GI Bill funded, moderate engagement, variable GPA",
        "params": {
            "age_mean": 30, "age_std": 6,
            "gpa_mean": 2.8, "gpa_std": 0.5,
            "engagement_factor": 0.55,
            "financial_aid_pct_mean": 0.85,
            "retention_prob": 0.78,
            "employment": {"full_time": 0.2, "part_time": 0.4, "unemployed": 0.4},
            "first_gen_prob": 0.40,
            "enrollment_status": "full_time",
            "credits_mean": 12, "credits_std": 3,
            "military_prob": 0.95,
        },
    },
    "disengaging_quietly": {
        "proportion": 0.12,
        "description": "Declining logins, missing assignments, will stop out in 2-3 terms",
        "params": {
            "age_mean": 28, "age_std": 7,
            "gpa_mean": 2.5, "gpa_std": 0.5,
            "engagement_factor": 0.60,  # starts moderate
            "financial_aid_pct_mean": 0.4,
            "retention_prob": 0.30,
            "employment": {"full_time": 0.4, "part_time": 0.35, "unemployed": 0.25},
            "first_gen_prob": 0.30,
            "enrollment_status": "full_time",
            "credits_mean": 12, "credits_std": 3,
            "engagement_decay": 0.20,  # per-term decay factor
            "gpa_trend": -0.15,
        },
    },
    "financially_stressed": {
        "proportion": 0.10,
        "description": "Good ability but payment issues, sporadic enrollment",
        "params": {
            "age_mean": 29, "age_std": 7,
            "gpa_mean": 2.9, "gpa_std": 0.4,
            "engagement_factor": 0.60,
            "financial_aid_pct_mean": 0.25,
            "retention_prob": 0.60,
            "employment": {"full_time": 0.3, "part_time": 0.4, "unemployed": 0.3},
            "first_gen_prob": 0.45,
            "enrollment_status": "half_time",
            "credits_mean": 9, "credits_std": 3,
            "financial_stress_high": True,
        },
    },
    "part_time_persistent": {
        "proportion": 0.05,
        "description": "Very slow progress, 1-2 courses, never stops, low engagement but passes",
        "params": {
            "age_mean": 40, "age_std": 8,
            "gpa_mean": 2.7, "gpa_std": 0.3,
            "engagement_factor": 0.35,
            "financial_aid_pct_mean": 0.3,
            "retention_prob": 0.93,
            "employment": {"full_time": 0.65, "part_time": 0.25, "unemployed": 0.10},
            "first_gen_prob": 0.35,
            "enrollment_status": "less_than_half",
            "credits_mean": 4, "credits_std": 1,
        },
    },
}

# ── Feature Engineering Definitions ──────────────────────────────────────────
COMPOSITE_INDICES = {
    "academic_momentum_index": {
        "components": ["term_gpa", "assignment_submission_rate", "credit_completion_rate"],
        "method": "zscore_mean",
    },
    "engagement_index": {
        "components": ["lms_logins_per_week", "discussion_posts", "video_watch_pct"],
        "method": "zscore_mean",
    },
    "financial_stress_index": {
        "components": ["tuition_balance", "financial_aid_pct", "payment_on_time"],
        "signs":      [1, -1, -1],
        "method": "zscore_mean",
    },
    "support_utilization_index": {
        "components": ["advisor_contacts", "tutoring_sessions", "support_ticket_count"],
        "method": "zscore_mean",
    },
    "communication_responsiveness": {
        "components": ["email_open_rate", "survey_response_rate"],
        "method": "zscore_mean",
    },
}

LAG_FEATURES = {
    "term_gpa":          [1, 2],
    "lms_logins_per_week": [1, 2],
    "tuition_balance":   [1],
    "engagement_index":  [1, 2],
    "financial_stress_index": [1],
}

DELTA_FEATURES = [
    ("gpa_change",        "term_gpa",          1),
    ("login_trend_3t",    "lms_logins_per_week", 3),  # slope over 3 terms
    ("balance_change",    "tuition_balance",    1),
    ("engagement_delta",  "engagement_index",   1),
]

RATIO_FEATURES = {
    "support_per_credit":       ("advisor_contacts", "credits_attempted"),
    "engagement_per_credit":    ("lms_logins_per_week", "credits_attempted"),
    "financial_burden":         ("tuition_balance", "scholarship_amount"),
    "gpa_vs_difficulty":        ("term_gpa", "avg_course_difficulty"),
    "engagement_academic_gap":  ("engagement_index", "academic_momentum_index"),
}

# ── Analysis Parameters ──────────────────────────────────────────────────────
PCA_N_COMPONENTS = 10
CLUSTER_RANGE = range(4, 15)  # test 4-14 clusters
GRANGER_MAX_LAG = 3
VAR_MAX_LAG = 3
MARKOV_N_STATES = 8

# Numeric columns to use in analysis (excludes categoricals and IDs)
NUMERIC_SIGNAL_GROUPS = [
    "academic", "engagement", "financial", "support",
    "course_level", "communication", "technology", "outcomes",
]

# Columns that are numeric across all groups (for quick reference)
def get_numeric_columns():
    """Return list of all numeric (non-categorical) signal columns."""
    cols = []
    for group_name in NUMERIC_SIGNAL_GROUPS:
        group = SIGNAL_GROUPS[group_name]
        for col, meta in group.items():
            if meta["type"] != "categorical":
                cols.append(col)
    return cols
