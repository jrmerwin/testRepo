#!/usr/bin/env python3
"""
Step 5: Scenario engine — run intervention what-if analyses.

Uses VAR impulse responses and Markov transitions to project the
population-level impact of various intervention strategies.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pandas as pd
import numpy as np
from config.settings import OUTPUT_DIR
from analysis.systems.scenario_engine import ScenarioEngine, run_default_scenarios


def main():
    print("=" * 60)
    print("STEP 5: Intervention Scenario Analysis")
    print("=" * 60)

    # Load required inputs
    irf_path = OUTPUT_DIR / "var_impulse_responses.csv"
    trans_path = OUTPUT_DIR / "transition_matrix.csv"
    canonical_path = OUTPUT_DIR / "canonical_student_signals.csv"

    missing = []
    if not irf_path.exists():
        missing.append("var_impulse_responses.csv")
    if not trans_path.exists():
        missing.append("transition_matrix.csv")
    if not canonical_path.exists():
        missing.append("canonical_student_signals.csv")

    if missing:
        print(f"ERROR: Missing files: {', '.join(missing)}")
        print("Run steps 1-4 first.")
        sys.exit(1)

    irf_df = pd.read_csv(irf_path)
    trans = pd.read_csv(trans_path, index_col=0)
    canonical = pd.read_csv(canonical_path)

    # Compute cluster sizes
    if "cluster_id" in canonical.columns:
        active = canonical[canonical["active_status"].isin(["active"])]
        cluster_sizes = active.groupby("cluster_id")["student_id"].nunique()
    else:
        print("ERROR: No cluster_id in canonical table. Run step 3.")
        sys.exit(1)

    print(f"IRF data: {len(irf_df)} records")
    print(f"Transition matrix: {trans.shape}")
    print(f"Cluster sizes:\n{cluster_sizes.to_string()}")

    # Run default scenarios
    comparison = run_default_scenarios(irf_df, trans, cluster_sizes)

    # ── Custom scenario: targeted advisor outreach for at-risk clusters ──
    print("\n" + "=" * 60)
    print("Custom Scenario: Targeted Advisor Outreach")
    print("=" * 60)

    engine = ScenarioEngine(irf_df, trans, cluster_sizes)

    # Find highest-risk clusters
    at_risk_clusters = []
    for state in trans.index:
        terminal_flow = 0
        for t in ["withdrawn", "stopped_out"]:
            if t in trans.columns:
                terminal_flow += trans.loc[state, t]
        if terminal_flow > 0.15:
            try:
                at_risk_clusters.append(int(state))
            except ValueError:
                pass

    if at_risk_clusters:
        result = engine.run_scenario(
            intervention="advisor_contacts",
            target_clusters=at_risk_clusters,
            shock_size=2.0,  # Aggressive outreach
            horizon=4,
        )
        print(f"\nTargeted intervention for at-risk clusters {at_risk_clusters}:")
        print(f"  +2σ advisor contacts over 4 terms")
        print(f"  Students targeted: {result['total_students_targeted']:,}")
        print(f"  Projected additional retentions: {result['total_additional_retained']:,}")
        print(f"  Retention lift: {result['retention_lift_pct']}%")

        if len(result["per_cluster"]) > 0:
            print("\nPer-cluster breakdown:")
            print(result["per_cluster"].to_string(index=False))
    else:
        print("  No clearly at-risk clusters identified from transition matrix.")

    # ── Summary ──────────────────────────────────────────────────────────
    print("\n" + "=" * 60)
    print("Pipeline Complete — Summary of All Outputs")
    print("=" * 60)
    outputs = sorted(OUTPUT_DIR.glob("*"))
    for f in outputs:
        if f.is_file():
            size_kb = f.stat().st_size / 1024
            print(f"  {f.name:45s} {size_kb:8.1f} KB")

    print("\n✓ Step 5 complete. All outputs in outputs/")
    print("\nKey files for review:")
    print("  - cluster_summary.txt           → Archetype profiles")
    print("  - systems_graph.png             → Causal map visualization")
    print("  - granger_causality.csv         → Directed causal edges")
    print("  - var_impulse_responses.csv     → Intervention effect estimates")
    print("  - scenario_comparison.csv       → What-if analysis results")
    print("  - transition_heatmap.png        → Archetype stability")


if __name__ == "__main__":
    main()
