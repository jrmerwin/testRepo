#!/usr/bin/env python3
"""
Step 2: Build the canonical student-term table with feature engineering.

Reads the raw synthetic data, builds the spine, aligns signals,
and engineers composite indices, lags, deltas, and ratios.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pandas as pd
from etl.canonical import build_canonical_table
from storage.database import StudentDB
from config.settings import OUTPUT_DIR


def main():
    print("=" * 60)
    print("STEP 2: Building canonical student-term table")
    print("=" * 60)

    # Load raw data
    raw_path = OUTPUT_DIR / "raw_synthetic_data.csv"
    if not raw_path.exists():
        print("ERROR: Run 01_generate_data.py first.")
        sys.exit(1)

    raw = pd.read_csv(raw_path)
    print(f"Loaded raw data: {len(raw):,} rows × {raw.shape[1]} columns")

    # Build canonical
    canonical = build_canonical_table(raw, save=True)

    # Verify dimensions
    print(f"\n--- Canonical table summary ---")
    print(f"Rows:    {len(canonical):,}")
    print(f"Columns: {canonical.shape[1]}")
    print(f"Students: {canonical['student_id'].nunique():,}")
    print(f"Terms:    {canonical['term_code'].nunique()}")
    print(f"Data completeness (mean): {canonical['data_completeness'].mean():.1%}")

    # Show engineered features
    eng_cols = [c for c in canonical.columns if
                c.endswith("_index") or c.endswith("_lag1") or c.endswith("_lag2") or
                c.endswith("_change") or c.endswith("_trend_3t") or c.endswith("_delta") or
                c in ["support_per_credit", "engagement_per_credit", "financial_burden",
                       "gpa_vs_difficulty", "engagement_academic_gap", "data_completeness"]]
    print(f"\nEngineered features ({len(eng_cols)}):")
    for col in sorted(eng_cols):
        print(f"  {col}")

    # Save to DuckDB
    with StudentDB() as db:
        db.replace_canonical(canonical)
        print(f"\nLoaded into DuckDB: {db.row_count('canonical'):,} rows × "
              f"{len(db.table_info('canonical')):,} columns")

    print("\n✓ Step 2 complete.")
    return canonical


if __name__ == "__main__":
    main()
