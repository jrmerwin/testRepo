#!/usr/bin/env python3
"""
Step 3: Descriptive analytics — PCA, clustering, and archetype profiling.

Identifies independent dimensions of student variation, discovers
student archetypes via K-Means, and validates against known generation personas.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pandas as pd
from storage.database import StudentDB
from analysis.descriptive.pca import run_pca, top_loadings
from analysis.descriptive.clustering import find_optimal_clusters, run_clustering, validate_clusters
from analysis.descriptive.profiling import profile_clusters, cluster_summary_report
from config.settings import OUTPUT_DIR


def main():
    print("=" * 60)
    print("STEP 3: Descriptive Analytics")
    print("=" * 60)

    # Load canonical table
    canonical_path = OUTPUT_DIR / "canonical_student_signals.csv"
    if not canonical_path.exists():
        print("ERROR: Run 02_build_canonical.py first.")
        sys.exit(1)

    df = pd.read_csv(canonical_path)
    # Filter to active terms only for clustering
    active = df[df["active_status"].isin(["active", "graduated"])].copy()
    print(f"Loaded: {len(df):,} rows, active subset: {len(active):,} rows")

    # ── PCA ──────────────────────────────────────────────────────────────
    print("\n--- PCA Analysis ---")
    pca_results = run_pca(active)
    print("\nTop loadings for PC1 (primary dimension):")
    print(top_loadings(pca_results["loadings"], "PC1", 8).to_string())
    print("\nTop loadings for PC2:")
    print(top_loadings(pca_results["loadings"], "PC2", 8).to_string())

    # ── Clustering ───────────────────────────────────────────────────────
    print("\n--- Clustering ---")
    print("Finding optimal k...")
    opt = find_optimal_clusters(active, k_range=range(5, 13))
    best_k = opt["best_k"]

    print(f"\nRunning K-Means with k={best_k}...")
    clustered, km_model, scaler = run_clustering(active, k=best_k)

    # Propagate cluster IDs back to full dataset
    cluster_map = clustered[["student_id", "term_code", "cluster_id"]].copy()
    df = df.merge(cluster_map, on=["student_id", "term_code"], how="left")
    # Forward-fill cluster for inactive terms
    df["cluster_id"] = df.groupby("student_id")["cluster_id"].ffill()
    df["cluster_id"] = df["cluster_id"].fillna(-1).astype(int)

    # ── Validation ───────────────────────────────────────────────────────
    print("\n--- Cluster Validation ---")
    ct = validate_clusters(clustered)

    # ── Profiling ────────────────────────────────────────────────────────
    print("\n--- Archetype Profiling ---")
    profiles = profile_clusters(clustered)
    report = cluster_summary_report(clustered)

    # Save updated canonical with clusters
    df.to_csv(OUTPUT_DIR / "canonical_student_signals.csv", index=False)
    with StudentDB() as db:
        db.replace_canonical(df)

    print("\n✓ Step 3 complete.")
    print(f"  Outputs: pca_*.csv/png, clustering_*.csv/png, cluster_*.csv/txt")
    return df


if __name__ == "__main__":
    main()
