#!/usr/bin/env python3
"""
Step 1: Generate synthetic student data.

Creates ~40-60k student-term records from 8 latent archetypes
with realistic correlations, temporal dynamics, and intervention effects.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from collectors.synthetic_generator import SyntheticGenerator
from storage.database import StudentDB
from config.settings import OUTPUT_DIR, NUM_STUDENTS


def main():
    print("=" * 60)
    print(f"STEP 1: Generating synthetic data ({NUM_STUDENTS:,} students)")
    print("=" * 60)

    gen = SyntheticGenerator(n_students=NUM_STUDENTS)
    df = gen.generate()

    print(f"\nGenerated: {len(df):,} rows × {df.shape[1]} columns")
    print(f"Students: {df['student_id'].nunique():,}")
    print(f"Terms:    {df['term_code'].nunique()}")
    print(f"\nArchetype distribution:")
    print(df.groupby("archetype_true")["student_id"].nunique().sort_values(ascending=False).to_string())
    print(f"\nActive status distribution:")
    print(df["active_status"].value_counts().to_string())
    print(f"\nRetention rate: {df['retained_next_term'].mean():.1%}")
    print(f"Avg term GPA: {df['term_gpa'].mean():.2f}")

    # Save to CSV
    out_path = OUTPUT_DIR / "raw_synthetic_data.csv"
    df.to_csv(out_path, index=False)
    print(f"\nSaved to {out_path}")

    # Save to DuckDB
    with StudentDB() as db:
        db.replace_canonical(df)  # Temporary: use canonical table for raw
        print(f"Loaded into DuckDB: {db.row_count('canonical'):,} rows")

    print("\n✓ Step 1 complete.")
    return df


if __name__ == "__main__":
    main()
