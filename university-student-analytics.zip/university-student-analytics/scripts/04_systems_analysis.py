#!/usr/bin/env python3
"""
Step 4: Systems analysis — correlation, lag, Granger causality,
systems graph, VAR impulse response, and Markov transitions.

This is the core analytical step that builds the causal model.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pandas as pd
from config.settings import OUTPUT_DIR
from analysis.systems.correlation import (
    compute_correlation_matrix, cross_group_summary,
    strongest_cross_group_pairs, plot_correlation_heatmap,
)
from analysis.systems.lag_analysis import compute_lagged_correlations, find_leading_indicators
from analysis.systems.granger import run_granger_tests
from analysis.systems.systems_graph import (
    build_systems_graph, export_graph, plot_systems_graph, find_intervention_targets,
)
from analysis.systems.var_models import (
    fit_var_by_archetype, compute_intervention_effects, plot_irf_by_cluster,
)
from analysis.systems.markov import (
    compute_transition_matrix, analyze_stability,
    steady_state_distribution, plot_transition_heatmap,
)


def main():
    print("=" * 60)
    print("STEP 4: Systems Analysis")
    print("=" * 60)

    canonical_path = OUTPUT_DIR / "canonical_student_signals.csv"
    if not canonical_path.exists():
        print("ERROR: Run steps 1-3 first.")
        sys.exit(1)

    df = pd.read_csv(canonical_path)
    active = df[df["active_status"].isin(["active", "graduated"])].copy()
    print(f"Loaded: {len(df):,} rows, active: {len(active):,}")

    # ── 4a: Correlation Matrix ───────────────────────────────────────────
    print("\n" + "=" * 40)
    print("4a: Cross-Group Correlations")
    print("=" * 40)
    corr = compute_correlation_matrix(active)
    cross = cross_group_summary(corr)
    top_pairs = strongest_cross_group_pairs(corr, top_n=20)
    plot_correlation_heatmap(corr)

    # ── 4b: Lag Analysis ─────────────────────────────────────────────────
    print("\n" + "=" * 40)
    print("4b: Lag Analysis — Leading Indicators")
    print("=" * 40)
    lag_corrs = compute_lagged_correlations(active)
    leading = find_leading_indicators(lag_corrs)

    # ── 4c: Granger Causality ────────────────────────────────────────────
    print("\n" + "=" * 40)
    print("4c: Granger Causality Tests")
    print("=" * 40)
    granger = run_granger_tests(df, method="aggregate")

    # ── 4d: Systems Graph ────────────────────────────────────────────────
    print("\n" + "=" * 40)
    print("4d: Systems Graph Construction")
    print("=" * 40)
    G = build_systems_graph(granger, corr)
    export_graph(G)
    plot_systems_graph(G)
    targets = find_intervention_targets(G)

    # ── 4e: VAR Models ───────────────────────────────────────────────────
    print("\n" + "=" * 40)
    print("4e: VAR Impulse Response Models")
    print("=" * 40)
    if "cluster_id" in active.columns:
        var_results = fit_var_by_archetype(active, cluster_col="cluster_id")
        if var_results:
            irf_df = compute_intervention_effects(var_results)
            plot_irf_by_cluster(var_results, "advisor_contacts")
        else:
            print("  No VAR models fitted (insufficient term-level data per cluster)")
            irf_df = pd.DataFrame()
    else:
        print("  Skipping: no cluster_id column. Run step 3 first.")
        var_results = {}
        irf_df = pd.DataFrame()

    # ── 4f: Markov Transitions ───────────────────────────────────────────
    print("\n" + "=" * 40)
    print("4f: Markov Transition Dynamics")
    print("=" * 40)
    if "cluster_id" in df.columns:
        trans = compute_transition_matrix(df, state_col="cluster_id")
        stability = analyze_stability(trans)
        steady = steady_state_distribution(trans)
        plot_transition_heatmap(trans)
    else:
        print("  Skipping: no cluster_id column.")
        trans = pd.DataFrame()

    # Save VAR results for scenario engine
    if len(irf_df) > 0:
        irf_df.to_csv(OUTPUT_DIR / "var_impulse_responses.csv", index=False)

    print("\n✓ Step 4 complete.")
    print("  Outputs: correlation_*.csv/png, lagged_*.csv, granger_*.csv,")
    print("           systems_graph.*, var_*.csv/png, transition_*.csv/png")


if __name__ == "__main__":
    main()
